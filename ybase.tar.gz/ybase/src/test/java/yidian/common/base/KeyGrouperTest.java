package yidian.common.base;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by sunshangchun on 16/3/22.
 */
public class KeyGrouperTest {
    @Test
    public void testAdd() throws Exception {
        final Map<Integer, Integer> output = new HashMap<>();
        KeyGrouper<Integer, Integer> keyGrouper = new KeyGrouper<>(
                new KeyGrouper.Reducer<Integer, Integer>() {
                    @Override
                    public void reduce(Integer key, List<Integer> values) {
                        int sum = 0;
                        for (int i = 0; i < values.size(); ++i) {
                            sum += values.get(i);
                        }
                        output.put(key, sum);
                    }
                });
        keyGrouper.add(5, 6);
        keyGrouper.add(5, 1);
        keyGrouper.add(6, 2);
        keyGrouper.add(8, 7);
        keyGrouper.add(8, 3);
        keyGrouper.cleanUp();

        Assert.assertEquals(7, (int) output.get(5));
        Assert.assertEquals(2, (int) output.get(6));
        Assert.assertEquals(10, (int) output.get(8));
        Assert.assertEquals(3, (int) output.size());
    }

    @Test
    public void testString() throws Exception {
        Map<String, Integer> result = new HashMap<>();

        KeyGrouper<String, Integer> keyGrouper = new KeyGrouper<>(
                (k, v) -> {
                    AtomicInteger sum = new AtomicInteger(0);

                    v.forEach(iv -> sum.addAndGet(iv));
                    result.put(k, sum.get());
                }
        );
        keyGrouper.add("5", 6);
        keyGrouper.add("5", 7);
        keyGrouper.add("6", 3);
        keyGrouper.add("2", 2);
        keyGrouper.add("2", 1);
        keyGrouper.add("7", 1);
        keyGrouper.cleanUp();
        Assert.assertEquals(3, (int) result.get("2"));
        Assert.assertEquals(13, (int) result.get("5"));
        Assert.assertEquals(3, (int) result.get("6"));
        Assert.assertEquals(1, (int) result.get("7"));
        System.out.print(result);
    }
}