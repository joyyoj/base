package yidian.common.base;

import org.junit.Assert;
import org.junit.Test;

import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 * Created by sunshangchun on 16/3/24.
 */
public class DateUtilsTest {

    @Test
    public void testFormatDateTime() throws Exception {
        long time = DateUtils.toTimestamp("2016-01-02");
        String dateTime = DateUtils.toDateTime(time);

        Assert.assertEquals(dateTime, "2016-01-02 00:00:00");

    }

    @Test
    public void testToTimestamp_Timezone() {
        String dateTime = DateUtils.formatDateTime("2016-03-24 12:16:05 +0000");
//        String dateTime = DateUtils.formatDateTime("2009-01-10 17:18:44 +0000");

        System.out.println(dateTime);
    }


    @Test
    public void testFloor() {
        long time = DateUtils.toTimestamp("2015-01-15 04:32:17");

        long after = DateUtils.floorTimestamp(time, 60, TimeUnit.SECONDS);
        Assert.assertEquals("2015-01-15 04:32:00", DateUtils.toDateTime(after));

        after = DateUtils.floorTimestamp(time, 60, TimeUnit.MINUTES);
        Assert.assertEquals("2015-01-15 04:00:00", DateUtils.toDateTime(after));

        after = DateUtils.floorTimestamp(time, 1, TimeUnit.DAYS);
        Assert.assertEquals("2015-01-15 00:00:00", DateUtils.toDateTime(after));
    }

    @Test
    public void testFloor_2() {
        long timestamp = DateUtils.floorTimestamp(6000, 5000, TimeUnit.MILLISECONDS,
                TimeZone.getTimeZone("UTC"));
        System.out.println(timestamp);
    }
}