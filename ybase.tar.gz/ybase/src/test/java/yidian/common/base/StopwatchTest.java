package yidian.common.base;

import org.junit.Test;

/**
 * Created by sunshangchun on 16/7/22.
 */
public class StopwatchTest {
    @Test
    public void testAll() throws Exception {
        Stopwatch stopwatch = Stopwatch.createStarted();
        int timeMs = stopwatch.elapsedMilli();
        System.out.println(timeMs);
        stopwatch.restart();
        Thread.sleep(150);
        System.out.println(stopwatch.elapsedMilli());
    }
}
