package yidian.common.base;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Created by sunshangchun on 15/12/10.
 */
public class StorageUnitTest {
    @Test
    public void testToBytes() throws Exception {
        Assert.assertEquals(2048, StorageUnit.KB.toBytes(2));
    }

    @Test
    public void testParseFrom() {
        long bytes = StorageUnit.parseFrom("5MB");
        Assert.assertEquals(5 * 1024 * 1024, bytes);

        bytes = StorageUnit.parseFrom("5Mb");
        Assert.assertEquals(5 * 1024 * 1024 / 8, bytes);
    }
}