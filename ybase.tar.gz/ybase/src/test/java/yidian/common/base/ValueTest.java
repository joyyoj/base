package yidian.common.base;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by sunshangchun on 16/5/12.
 */
public class ValueTest {
    @Test
    public void testValue() {
        PrimitiveValue value = PrimitiveValue.empty();
        Assert.assertEquals(null, value.asString());

        value = PrimitiveValue.of("t1");
        Assert.assertEquals("t1", value.asString());

        value = PrimitiveValue.of(12);
        Assert.assertEquals("12", value.asString());
    }

    @Test
    public void testNumber() {
        PrimitiveValue value = PrimitiveValue.of(5.0);

        float a = value.asFloat();
        Assert.assertTrue(5.0F == a);
        Assert.assertTrue(5.0 == value.asDouble());

        Assert.assertTrue(5 == value.asShort());
        Assert.assertTrue(5 == value.asInt());
        Assert.assertTrue(5 == value.asLong());
    }

    @Test
    public void testToLong() {
        short number = (short) 500;
        System.out.println(new PrimitiveValue(number).asLong());
    }
}