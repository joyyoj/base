package yidian.common.base;

import junit.framework.Assert;
import org.junit.Test;
import yidian.common.util.Bytes;
import yidian.common.util.OptHashMap;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map;

/**
 * Created by sunshangchun on 15/12/18.
 */
public class ByteArrayTest {
    byte[] b1 = new byte[]{1, 2, 3};
    byte[] b2 = new byte[]{5, 1, 2, 3, 4};
    ByteArray ba1 = ByteArray.ref(b1);
    ByteArray ba2 = ByteArray.ref(b2, 1, 3);

    @Test
    public void testCompareTo() throws Exception {
        int cmp = ba1.compareTo(ba2);

        Assert.assertEquals(0, cmp);
        cmp = ba1.compareTo(ByteArray.ref(b2));
        Assert.assertTrue(cmp < 0);
    }

    @Test
    public void testHashCode() throws Exception {
        Assert.assertEquals(ba1.hashCode(), ba2.hashCode());
        Assert.assertTrue(ba1.hashCode() > 0);
    }

    @Test
    public void testOffset() throws IOException {
        ByteArray ba = ByteArray.ref(b1, 1, 2);
        Assert.assertEquals(1, ba.offset());
        Assert.assertEquals(2, ba.size());

        byte[] out = ba.copyBytes();
        Assert.assertEquals(2, out[0]);
        Assert.assertEquals(3, out[1]);
        Assert.assertEquals(2, out.length);
    }

    @Test
    public void testCopyFrom() {
        ByteBuffer data = ByteBuffer.wrap(new byte[] {2, 3 , 1}, 1, 2);
        ByteArray out = ByteArray.copyFrom(data);

        Assert.assertEquals(2, out.size());
        Assert.assertEquals(3, out.byteAt(0));
        Assert.assertEquals(1, out.byteAt(1));
    }

    @Test
    public void testIntByteArray() {
        int i = 1323;
        ByteArray bytes = ByteArrays.fromInt(i);
        int o = Bytes.toInt(bytes.getOrCopyBytes());

        Assert.assertEquals(1323, bytes.hashCode());
        ByteArray obytes = ByteArrays.fromInt(o);
        Assert.assertEquals(bytes, obytes);
        Assert.assertEquals(bytes.hashCode(), obytes.hashCode());

        Map<ByteArray, Double> v = new OptHashMap<>();
        v.put(obytes, 1.5);

        Assert.assertEquals(1.5, v.get(bytes));
    }
}