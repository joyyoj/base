package yidian.common.base;

import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.typesafe.config.ConfigFactory;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by sunshangchun on 15/12/10.
 */
public class YConfigTest {
    private YConfig yConfig = YConfig.create(ConfigFactory.load("yconfig-test.conf"));
    YConfig.Vars threadSize = YConfig.Vars.of("thread.size", 5);
    YConfig.Vars threadNum = YConfig.Vars.of("thread.num", 3);
    YConfig.Vars noneKey = YConfig.Vars.of("not.in.file", 2);

    @Test
    public void testGet() throws Exception {
        Assert.assertEquals(6, yConfig.getInt(threadSize));  // should read from resource
        Assert.assertEquals(5, yConfig.getInt(threadNum));   // should read from file
        Assert.assertEquals("5", yConfig.get(threadNum));   // should read from file
        Assert.assertEquals(2, yConfig.getInt(noneKey));     // from default
        Assert.assertEquals("2", yConfig.get(noneKey));     // from default
    }

    @Test
    public void testParseFromHadoopConf_NotFound() throws Exception {
        YConfig yConfig = YConfig.createFromHadoopConf("yconfig-hadoop2.xml");
        Assert.assertNotNull(yConfig);
    }

    @Test
    public void testOpt_Present() {
        Assert.assertEquals(true, yConfig.hasPath(threadSize.name()));
        int v = yConfig.getOptInt(threadSize.name()).get();
        Assert.assertEquals(6, v);  // should read from resource

    }

    @Test
    public void testOpt_Absent() {
        Assert.assertEquals(false, yConfig.hasPath(noneKey.name()));
        Integer i = yConfig.getOptInt(noneKey.name()).orNull();
        Assert.assertTrue(i == null);
    }

    @Test
    public void testLoad_default() {
        YConfig config = YConfig.load();
        Assert.assertEquals("a", config.getOptString("l1.a").get());
        Assert.assertEquals("b", config.getOptString("l1.b").get());
        Assert.assertEquals("c", config.getOptString("l1.c").get());
    }

    @Test
    public void test_withFallback() {
        YConfig config = YConfig.loadFile("reference.conf");
        YConfig merge = config.withFallback(YConfig.loadFile("application.conf"));
        System.out.println(merge.getOptString("l1.a"));
    }

    @Test
    public void testParseFromHadoopConf() throws Exception {
        YConfig yConfig = YConfig.createFromHadoopConf("yconfig-hadoop.xml");
        YConfig test = yConfig.getConfig("test");

        String value = yConfig.getOptString("test.string").get();
        Assert.assertEquals("str", value);

        value = yConfig.getOptString("test.empty").get();
        Assert.assertEquals("", value);

        int iValue = yConfig.getOptInt("test.int").get();
        Assert.assertEquals(5, iValue);

        boolean bvalue = yConfig.getOptBoolean("test.bool").get();
        Assert.assertEquals(true, bvalue);

        value = yConfig.getOptString("test.xx").orNull();
        Assert.assertEquals(null, value);
    }

    @Test
    public void testIncludeHadoopConf() throws Exception {
        YConfig config = YConfig.create(ConfigFactory.load("include.conf"));
        Optional<String> testStr = config.getOptString("test.string");
        Optional<Integer> threadSize = config.getOptInt("thread.size");
        System.out.println(testStr);
        System.out.println(threadSize.get());
    }

    @Test
    public void testSet() throws Exception {
        YConfig config = YConfig.create(ConfigFactory.load());
        config = config.withValue("test.bool", false);
        Assert.assertEquals(false, config.getOptBoolean("test.bool").get());
    }

    @Test
    public void testCreate_FromIter() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put("\"abc", "3");

        YConfig yConfig = YConfig.create(map);
        String out = yConfig.get().getString("abc");
        System.out.println(out);
    }

    @Test
    public void testToMap() throws Exception {
        YConfig yConfig = YConfig.newBuiler().set("vb", true).set("vi", 3).set("vs", "my").set("p.b", false)
                .set("p.i", 4).set("p.s", "you").build();
        Assert.assertEquals(3, yConfig.get().getInt("vi"));
        Assert.assertEquals(4, yConfig.get().getInt("p.i"));

        Map<String, String> output = yConfig.toMap();

        Assert.assertEquals(6, output.size());

        Assert.assertEquals("true", output.get("vb"));
        Assert.assertEquals("3", output.get("vi"));
        Assert.assertEquals("my", output.get("vs"));
        Assert.assertEquals("false", output.get("p.b"));
        Assert.assertEquals("4", output.get("p.i"));
        Assert.assertEquals("you", output.get("p.s"));

        System.out.println(Joiner.on(",").withKeyValueSeparator(":").join(output));
    }

    @Test
    public void testFromMap() throws Exception {
       Map<String, String> s = new HashMap<>();
        s.put("topology.debug", "false");
        s.put("topology.debugs", "z");
        s.put("topology", "hello");
        YConfig yconf = YConfig.create(s);
        System.out.println(yconf.getOptString("topology.debug").or("n"));
        System.out.println(yconf.getOptString("topology.debugs").or("n"));
//        System.out.println(yconf.getOptString("topology").or("m"));
    }

    @Test
    public void testLoadFile() {
        YConfig yConfig = YConfig.loadFile("test.conf");

        Assert.assertEquals("../tests", yConfig.getOptString("basedir").orNull());
    }

    @Test
    public void testSubstitude() {
        YConfig yconf = YConfig.load();
        System.out.println(yconf.getOptString("u1").get());
        System.out.println(yconf.getOptString("u2").get());
    }
}