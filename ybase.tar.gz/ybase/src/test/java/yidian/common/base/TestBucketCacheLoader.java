package yidian.common.base;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableList;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class TestBucketCacheLoader {
    @Test
    public void test() throws Exception {
        final AtomicInteger called = new AtomicInteger(0);
        LoadingCache<String, String> cache =
                CacheBuilder.newBuilder().build(new BucketCacheLoader<String, String>() {
                    private static final String nullString = "";
                    @Override
                    protected Map<String, String> loadAll(List<String> keys) throws Exception {
                        called.incrementAndGet();
                        Map<String, String> result = new HashMap<String, String>();
                        for (int i = 0; i < keys.size(); i += 2) {
                            result.put(keys.get(i), String.valueOf(i));
                        }
                        return result;
                    }

                    @Override
                    protected String Null() {
                        return nullString;
                    }
                });
        String a = cache.get("5");

        System.err.println(a);
        System.err.println("n");
        Map<String, String> b = cache.getAll(ImmutableList.of("a", "5", "c", "d"));
        for (Map.Entry<String, String> entry : b.entrySet()) {
            System.err.println(entry.getKey() + ":" + entry.getValue());
        }
        System.err.println(called.get());

    }
}
