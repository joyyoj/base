package yidian.common.base;

import com.google.common.collect.ImmutableList;
import junit.framework.Assert;
import lombok.val;
import org.junit.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by sunshangchun on 15/6/13.
 */
public class TestBucketProcessor {
    final Set<Integer> processed = new HashSet<>();
    final AtomicInteger called = new AtomicInteger(0);

    @Test
    public void testProcess() throws Exception {
        val bucketProcessor = new BucketProcessor<Integer>(2)
                .setReducer((ints) -> batchExec(ints));
        bucketProcessor.process(ImmutableList.of(1, 2, 3, 4, 5));
        Assert.assertEquals(5, processed.size());
        Assert.assertEquals(3, called.get());
    }

    public void batchExec(List<Integer> ints) throws Exception {
        called.incrementAndGet();
        processed.addAll(ints);
    }
}
