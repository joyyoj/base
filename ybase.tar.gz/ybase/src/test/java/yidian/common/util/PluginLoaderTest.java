package yidian.common.util;

import org.junit.Assert;
import org.junit.Test;
import yidian.common.base.ByteArray;

/**
 * Created by sunshangchun on 16/3/31.
 */
public class PluginLoaderTest {
    public static class ByteArrayP1 extends ByteArray {
        public byte[] array() {
            return "p1".getBytes();
        }
    }

    public static class ByteArrayP2 extends ByteArray {
        @Override
        public byte[] array() {
            return "p2".getBytes();
        }
    }

    @Test
    public void testLoad() throws Exception {
        PluginLoader<ByteArray> loader = PluginLoader.load(ByteArray.class);

        Assert.assertTrue(loader.keySet().contains("p1"));
        Assert.assertTrue(loader.keySet().contains("p2"));

        ByteArray p1 = loader.get("p1");
        ByteArray p2 = loader.get("p2");
        ByteArray p11 = loader.get("p1");

        Assert.assertEquals("p1", p1.toStringUtf8());
        Assert.assertEquals("p2", p2.toStringUtf8());
        Assert.assertTrue(p1 != p11);
    }

    @Test
    public void load_memoize() throws Exception {
        PluginLoader<ByteArray> loader = PluginLoader.find(ByteArray.class).memoize(true).load();
        ByteArray p1 = loader.get("p1");
        ByteArray p11 = loader.get("p1");
        Assert.assertTrue(p1 == p11);

    }
}