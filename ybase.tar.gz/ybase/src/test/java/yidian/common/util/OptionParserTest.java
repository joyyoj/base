package yidian.common.util;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.typesafe.config.ConfigParseOptions;
import com.typesafe.config.ConfigSyntax;
import org.junit.Assert;
import org.junit.Test;
import yidian.common.base.YConfig;

/**
 * Created by sunshangchun on 16/6/29.
 */
public class OptionParserTest {
    @Test
    public void parse() throws Exception {
        OptionParser parser = new OptionParser();
        String[] otherArgs = parser.parse(new String[] {
                "--a.b=1", "--hbase.b=zz", "--conf=test.conf", "m", "6"
        });
        Assert.assertArrayEquals(new String[] { "m", "6"}, otherArgs);
        Assert.assertEquals("zz", parser.getOptions().getOptString("hbase.b").get());
        Assert.assertEquals("1", parser.getOptions().getOptString("a.b").get());

        YConfig finalConf = parser.getConf(false);
        System.out.println(finalConf.toString());
    }

    @Test
    public void testParse() throws Exception {
        Config config = ConfigFactory.parseString("input=hdfs://a:8020",
                ConfigParseOptions.defaults().setSyntax(ConfigSyntax.PROPERTIES));
        System.out.println(config.getString("input"));

        OptionParser parser = new OptionParser();
        parser.parse(new String[] {
                "--input=hdfs://103-8-215-sh-100-F09.yidian.com:8020/user/ploader/profile//2016-07-06"
        });
        YConfig yconf = parser.getConf();
        System.out.println(yconf.getOptString("input").get());
    }
}