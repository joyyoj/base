package yidian.common.util;

import org.junit.Test;

/**
 * Created by sunshangchun on 16/4/29.
 */
public class PercentPredicateTest {
    @Test
    public void apply() throws Exception {
        PercentPredicate predicate = new PercentPredicate(0.01);
        predicate.apply(null);
        predicate.getTotalCount();
        predicate.getPassedCount();
    }

}