package yidian.common.test;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Created by sunshangchun on 15/12/16.
 */
public class TestUtilsTest {
    TestUtils utils = TestUtils.getDefault();

    @Test
    public void testGetOutput() throws Exception {
        String output1 = utils.output(TestUtils.getTestCase());
        System.out.print(output1);
//        Assert.assertEquals(output1.getAbsolutePath(), output2.getAbsolutePath());
    }

    @Test
    public void testTestDir() throws Exception {
        System.out.println(utils.getTestDir());
    }

    @Test
    public void testDiff() {
        int diff = utils.diff(TestUtils.getTestCase());
        Assert.assertEquals(0, diff);
    }
}