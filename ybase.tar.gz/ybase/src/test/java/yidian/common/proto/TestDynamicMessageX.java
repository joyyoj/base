package yidian.common.proto;

import com.google.protobuf.Descriptors;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.DynamicMessage;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by sunshangchun on 16/3/9.
 */
public class TestDynamicMessageX {
    @Test
    public void testBuilder_Simple() {
        DescriptorWrapper descriptorWrapper = new DescriptorWrapper.Builder()
                .newMessage("Test")
                .addField(FieldDescriptor.Type.STRING, "s1")
                .addField(FieldDescriptor.Type.INT32, "i1")
                .build();
        DynamicMessage msg = descriptorWrapper.newMessageBuilder("Test").get().setField("s1", "v1")
                .setField("i1", 5).build();
        System.out.println(msg);
    }

    @Test
    public void testBuilder_Repeated() {
        DescriptorWrapper descriptorWrapper = new DescriptorWrapper.Builder()
                .newMessage("Test")
                .addField(FieldDescriptor.Type.STRING, "s1")
                .addRepeatedField(FieldDescriptor.Type.STRING, "s2")
                .build();

        DynamicMessage msg = descriptorWrapper.newMessageBuilder("Test").get().setField("s1", "s1")
                .addRepeatedField("s2", "a1").addRepeatedField("s2", "a2")
                .addRepeatedField(1, "a3").build();

        System.out.println(msg.toString());
    }

    @Test
    public void testBuilder_Map() {
        DescriptorWrapper descriptorWrapper = new DescriptorWrapper.Builder()
                .newMessage("Test")
                .addMapField(FieldDescriptor.Type.STRING, FieldDescriptor.Type.STRING, "m1")
                .addMapField(FieldDescriptor.Type.STRING, FieldDescriptor.Type.INT32, "m2")
                .build();
        Descriptors.Descriptor desc = descriptorWrapper.findDescriptor("Test").get();
        Assert.assertTrue(desc.findFieldByName("m1").isMapField());
        DynamicMessage msg = descriptorWrapper.newMessageBuilder("Test").get()
                .putToMap(0, "k1", "v1")
                .putToMap(1, "k2", 20).build();

        System.out.println(msg);
    }
}
