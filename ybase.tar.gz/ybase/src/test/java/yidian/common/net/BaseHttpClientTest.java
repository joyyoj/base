package yidian.common.net;

import com.google.gson.JsonObject;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by zhc on 16/11/24.
 */
public class BaseHttpClientTest {

    @Test
    public void test() throws Exception {
        String url = "http://a4.go2yd.com/Website/mysql/channel";
        int socketTimeout = 10000;
        int connectTimeout = 10000;
        BaseHttpClient httpClient = BaseHttpClient.create(url, socketTimeout, connectTimeout);
        BaseHttpClient.Params params = new BaseHttpClient.Params();
        params.add("userid", "77");
        params.add("fields", "*");
//        Map<String, String> header = new HashMap<>();
//        header.put("Pragma", "no-cache");
//        httpClient.setHeader(header);
        try (CloseableHttpResponse response = httpClient.get("", params)) {
            JsonObject result = httpClient.getAsJsonObject(response);
            System.out.println(result);
        } catch (IOException e) {
            System.out.println("error");
        }
    }
}
