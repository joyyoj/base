package yidian.common.net;

import com.google.common.base.Optional;
import org.junit.Test;

import java.io.IOException;
import java.net.InetAddress;

/**
 * Created by sunshangchun on 16/6/7.
 */
public class InetUtilsTest {
    @Test
    public void test() throws IOException {
        Optional<InetAddress> localhost = InetUtils.getLocalHost();
        System.out.println(localhost.get().getHostAddress());
    }
}
