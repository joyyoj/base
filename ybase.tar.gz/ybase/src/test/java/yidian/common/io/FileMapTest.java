package yidian.common.io;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import junit.framework.Assert;
import lombok.val;
import org.junit.Ignore;
import org.junit.Test;
import yidian.common.base.StorageUnit;
import yidian.common.test.TestUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by sunshangchun on 15/12/18.
 */
public class FileMapTest {

    @Ignore
    @Test
    public void fileMap() throws Exception {
        val meta = FileMap.newMeta(SerDes.fixedInt32SerDe, SerDes.fixedDoubleSerDe);
        val file = new File("maptest");
        FileMap<Integer, Double> fileMap = FileMap.create(
                file,
                (int) StorageUnit.MB.toBytes(1),
                meta).setPersist(true);
        int max = 200000;
        for (int i = 0; i < max; ++i) {
            fileMap.put(i, (double) i);
        }
        for (int i = 0; i < 3; ++i) {
            fileMap.put(max + i, (double) i);
        }
        fileMap.cleanUp();

        FileMap<Integer, Double> fileMap2 = FileMap.<Integer, Double>open(file).deleteOnExit();
        for (int i = 0; i < max; ++i) {
            double v = fileMap2.get(i);
            Assert.assertTrue(Math.abs(i - v) < 1e-14);
        }
    }

    @Test
    public void putAndAdd() throws Exception {
        String[] dir = TestUtils.getTestCase();
        File output = new File(TestUtils.getDefault().output(dir));
        FileUtils.mkDirRecursively(output);

        File file = File.createTempFile("filecache", ".data", output);
        FileMap<String, String> fileCache = FileMap.create(file,
                (int) StorageUnit.KB.toBytes(100),
                FileMap.newMeta(SerDes.stringSerDe, SerDes.stringSerDe));

        for (int i = 0; i < 10; ++i) {
            fileCache.put("a" + i, String.valueOf(i));
        }
        for (int i = 0; i < 10; ++i) {
            String v = fileCache.get("a" + i);
            Assert.assertEquals(v, String.valueOf(i));
        }
    }

    @Test
    public void fileMeta() throws Exception {
        FileMap.FileMeta meta = FileMap.newMeta(SerDes.fixedInt32SerDe, SerDes.stringSerDe);
        meta.setVersion("1.0-1");

        val bos = new ByteArrayOutputStream(10000);
        CodedOutputStream cos = CodedOutputStream.newInstance(bos);
        meta.serialize(cos);
        cos.flush();
        val bytes = bos.toByteArray();
        val size = bos.size();

        val bis = new ByteArrayInputStream(bytes, 0, size);
        val meta2 = FileMap.FileMeta.parseFrom(CodedInputStream.newInstance(bis));

        System.out.println(meta2);
        Assert.assertEquals(meta.getKeySerDe().getClass(), meta2.getKeySerDe().getClass());
        Assert.assertEquals(meta.getValueSerDe().getClass(), meta2.getValueSerDe().getClass());
    }

    @Test
    public void index_SaveAndLoad() throws Exception {
        Map<Integer, FileMap.PageOffset> indexMap = new HashMap<>();
        indexMap.put(100, FileMap.PageOffset.of(100, 10));
        indexMap.put(101, FileMap.PageOffset.of(110, 90));
        val file = new File("./filemap.idx");
        file.deleteOnExit();

        FileMap.Index<Integer> index = new FileMap.Index<>(file);
        index.setMap(indexMap);
        index.save(SerDes.fixedInt32SerDe);

        FileMap.Index index2 = new FileMap.Index<>(file);
        index2.load(SerDes.fixedInt32SerDe);
        System.out.println(index2);
        Assert.assertEquals(indexMap, index2.getMap());
    }

    @Test
    public void indexForString() throws Exception {
        Map<String, FileMap.PageOffset> indexMap = new HashMap<>();

        indexMap.put("123", FileMap.PageOffset.of(100, 10));
        indexMap.put("455555", FileMap.PageOffset.of(110, 90));

        val file = new File("./filemap.idx");
        file.deleteOnExit();
        FileMap.Index index = new FileMap.Index<>(file);
        index.setMap(indexMap);
        index.save(SerDes.stringSerDe);

        FileMap.Index index2 = new FileMap.Index<>(file);
        index2.load(SerDes.stringSerDe);
        Assert.assertEquals(indexMap, index2.getMap());
    }
}