package yidian.common.io;

import org.junit.Test;
import yidian.common.test.TestUtils;

import java.io.File;

/**
 * Created by sunshangchun on 15/12/3.
 */
public class ZipUtilsTest {
    @Test
    public void testZipFolder() throws Exception {
        TestUtils utils = TestUtils.getDefault();
        String[] testCase = TestUtils.getTestCase();
        File folder = new File(utils.input(testCase[0]));
        File zipFile = new File(utils.output(testCase[0], testCase[1] + ".zip"));

        ZipUtils.zipFolder(folder, zipFile);
        folder = new File(utils.output(testCase[0], "testZipFolder"));
        ZipUtils.unzipFile(zipFile, folder);
    }
}