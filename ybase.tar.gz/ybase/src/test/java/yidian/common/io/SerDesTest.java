package yidian.common.io;

import lombok.val;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by sunshangchun on 16/11/8.
 */
public class SerDesTest {
    @Test
    public void doubleSerDe() {
        double d = 1.2345;
        val ba = SerDes.fixedDoubleSerDe.serialize(d);
        double s = SerDes.fixedDoubleSerDe.deserialize(ba);
        System.out.println(s);
        Assert.assertTrue(Math.abs(d - s) < 1e-14);
    }
}