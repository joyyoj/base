package yidian.common.io;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by sunshangchun on 15/12/18.
 */
public class LruCacheTest {
    @Test
    public void testRemoveEldestEntry() throws Exception {
        LruCache<Long, Long> map = new LruCache<>(3);
        map.put(1L, 3L);
        map.put(2L, 4L);
        map.put(1L, 4L);
        map.put(3L, 5L);
        map.put(2L, 9L);
        map.put(4L, 7L);
        Assert.assertNull(map.get(Long.valueOf(1)));
        Assert.assertEquals(9L, (long) map.get(Long.valueOf(2)));
        Assert.assertEquals(5L, (long) map.get(Long.valueOf(3)));
    }
}