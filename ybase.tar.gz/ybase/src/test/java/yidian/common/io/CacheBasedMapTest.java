package yidian.common.io;

import org.junit.Assert;
import org.junit.Test;
import yidian.common.base.StorageUnit;

import java.io.File;
import java.io.IOException;

/**
 * Created by sunshangchun on 15/12/18.
 */
public class CacheBasedMapTest {

    @Test
    public void testPut() throws IOException {
        File file = new File("temp-TestCacheMap");
        FileMap<String, String> fileMap = FileMap.create(file,
                (int) StorageUnit.MB.toBytes(4),
                FileMap.newMeta(SerDes.stringSerDe, SerDes.stringSerDe)).setFixed(true).deleteOnExit();
        CacheBasedMap<String, String> map = new CacheBasedMap<>(fileMap, 10);

        // 4k * 1000 = 4M
        int maxSize = 1033;
        for (int i = 0; i < maxSize; ++i) {
            map.put("k" + i, "v" + i);
        }
        System.out.println(map.size());
        Assert.assertEquals(maxSize, map.size());
        for (int i = 0; i < maxSize; ++i) {
            String v = map.get("k" + i);
            Assert.assertTrue(v.equals("v" + i));
        }
        try {
            map.put("k1034", "");
            fileMap.cleanUp();
            throw new IllegalStateException("should throw overflow exception");
        } catch (FileMap.DiskOverflowException e) {
            // expected.
        }
    }

    @Test
    public void testIterator() throws Exception {
//        File file = new File("cache");
//        CacheBasedStatMap statMap = new CacheBasedStatMap(file, 3, 1024 * 1024);
//        RowKey rowKey = new RowKey().setColumnId("1").setMatrixName(MatrixNames.UidDoc.name());
//        for (int i = 0; i < 5; ++i) {
//            statMap.put(rowKey, new CompactTuple());
//            statMap.put(new RowKey(rowKey).setColumnId(String.valueOf(i)), new CompactTuple());
//        }
//        Iterator<Map.Entry<RowKey, CompactTuple>> iter = statMap.iterator();
//        Set<RowKey> map = new HashSet<>();
//        while (iter.hasNext()) {
//            Map.Entry<RowKey, CompactTuple> entry = iter.next();
//            map.add(entry.getKey());
//        }
//        statMap.close();
//        Assert.assertEquals(5, map.size());
    }
}