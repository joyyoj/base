package yidian.common.http;

import com.google.common.base.Joiner;
import com.typesafe.config.Config;
import org.junit.Assert;
import org.junit.Test;
import yidian.common.net.Uris;

import java.net.URI;
import java.util.List;
import java.util.Map;

/**
 * Created by sunshangchun on 15/12/16.
 */
public class UrisTest {
    @Test
    public void testGetParams() throws Exception {
        URI uri = URI.create("http://yidian.com?p1=a1&p2=%2fb");
        Map<String, String> params = Uris.getParams(uri);
        Assert.assertEquals("a1", params.get("p1"));
        Assert.assertEquals("/b", params.get("p2"));
    }

    @Test
    public void testGetParams_MultiEqual() throws Exception {
        URI uri = URI.create("http://yidian.com?p1=a1&p2=p_day=2016-03-01/p_hour=24");
        Map<String, String> params = Uris.getParams(uri);
        Assert.assertEquals("a1", params.get("p1"));
        Assert.assertEquals("p_day=2016-03-01/p_hour=24", params.get("p2"));
    }

    @Test
    public void testGetParams_WithHttp() throws Exception {
        URI uri = URI.create("http://localhost?u=http://localhost&u.z=t&u.p1=v1");
        Config params = Uris.parseParams(uri);
        Assert.assertEquals("t", params.getString("u.z"));
    }

    @Test
    public void testGetUriPath() {
        List<String> path = Uris.getUriPath("/db/table//part");

        Assert.assertEquals("db", path.get(0));
        Assert.assertEquals("table", path.get(1));
        Assert.assertEquals("part", path.get(2));
        Assert.assertEquals(3, path.size());
    }

    @Test
    public void testJoinAddress() {
        String addr = Uris.joinAddress(new String[] { "sh01", "sh02", "sh03"}, 2181);
        Assert.assertEquals("sh01:2181,sh02:2181,sh03:2181", addr);
    }

    @Test
    public void testSplitAddress() {
        Map.Entry<List<String>, Integer> addr = Uris.splitAddress(" sh01:2181, sh02:2181, sh03:2181 ");

        Assert.assertEquals("sh01,sh02,sh03", Joiner.on(",").join(addr.getKey()));
        Assert.assertEquals(2181, (int) addr.getValue());
    }

    @Test
    public void testGetTablePath() {
        String path = "hcat://hive1:8081/ns/dbname/tablename/p_day=${day}/p_hour=${hour}?p_type=xx";
        Uris.TablePath tablePath = Uris.convertToTablePath(path);

        Assert.assertEquals("hcat", tablePath.scheme);
        Assert.assertEquals("hive1", tablePath.host);
        Assert.assertEquals(8081, tablePath.port);
        Assert.assertEquals("ns/dbname", tablePath.dbName);
        Assert.assertEquals("tablename", tablePath.tableName);
        Assert.assertEquals("${day}", tablePath.partitionName.get("p_day"));
        Assert.assertEquals("${hour}", tablePath.partitionName.get("p_hour"));
        Assert.assertEquals("xx", tablePath.query.get("p_type"));
    }

    @Test
    public void testGetTablePath_Simple() {
        String path = "store://userprofile/p_day=${day}/p_type=a,b?column=xx";
        Uris.TablePath tablePath = Uris.convertToTablePath(path);

        Assert.assertEquals("store", tablePath.getScheme());
        Assert.assertEquals("", tablePath.getDb());
        Assert.assertEquals("", tablePath.getTable());
        Assert.assertEquals(2, tablePath.getPartition().size());

    }

    @Test
    public void testGetTablePath_Complex() {
        String path = "morpheus://hadoop2-2.lg-4-e9.yidian.com,hadoop2-14.lg-4-e10.yidian.com,hadoop2-13.lg-4-e10.yidian.com:2181/serving/userprofile/p_day=${day, -1 day, yyyy-MM-dd}/p_type=apm_gender?column_name=activePM&service_name=userprofile_new_write";
        Uris.TablePath tablePath = Uris.convertToTablePath(path);
        Assert.assertEquals("morpheus", tablePath.scheme);
    }
}