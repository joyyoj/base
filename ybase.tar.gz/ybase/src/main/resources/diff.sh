#!/bin/bash
# sort utf8
export LC_ALL=C

cwd=$(cd `dirname $0`; pwd)
cd $cwd

dir1=$1
dir2=$2

IFS=$'\n'
ret=0
files=$(grep -Ilsr '.' "$dir1" | grep -v "\.st")
for file in $files; do
    echo $file
    a=$file
    b="${file/${dir1}/${dir2}}"
    sort -n -k '1' $a > $a.st
    sort -n -k '1' $b > $b.st
    diff -q $a.st $b.st
    err=$?
    rm $a.st
    rm $b.st
    if [[ $err -ne 0 ]]; then
        echo "vimdiff <(sort $a) <(sort $b)"
        ret=$err
    fi
done
exit $ret