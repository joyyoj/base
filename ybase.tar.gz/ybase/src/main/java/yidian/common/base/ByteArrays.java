package yidian.common.base;

import yidian.common.util.Bytes;

/**
 * Created by sunshangchun on 16/7/15.
 */
public class ByteArrays {
    public static ByteArray fromInt(int v) {
        return new IntByteArray(v);
    }

    public static ByteArray fromLong(long v) {
        return new LongByteArray(v);
    }

    static class LiteralByteArray extends ByteArray {
        private final byte[] raw;

        public LiteralByteArray() {
            this(ByteArray.EMPTY_BYTE);
        }

        public LiteralByteArray(byte[] buf) {
            this.raw = buf;
        }

        @Override
        public byte[] array() {
            return raw;
        }
    }

    static class ByteRef extends ByteArray {
        private int offset;
        private int len;
        private byte[] buf;

        public ByteRef(byte[] bytes, int offset, int len) {
            this.buf = bytes;
            this.offset = offset;
            this.len = len;
        }

        public byte[] array() {
            return buf;
        }

        @Override
        public int offset() {
            return offset;
        }

        @Override
        public int size() {
            return len;
        }
    }

    static class IntByteArray extends ByteArray {
        private int value;
        private volatile byte[] raw;

        public IntByteArray(int v) {
            this.value = v;
        }

        @Override
        public byte[] array() {
            if (raw == null) {
                raw = Bytes.toBytes(value);
            }
            return raw;
        }

        @Override
        public int size() {
            return Bytes.SIZEOF_INT;
        }

        @Override
        public int compareTo(ByteArray other) {
            if (other instanceof IntByteArray) {
                return Integer.compare(this.value, ((IntByteArray) other).value);
            } else {
                return super.compareTo(other);
            }
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof IntByteArray) {
                return this.value == ((IntByteArray) obj).value;
            } else {
                return super.equals(obj);
            }
        }

        @Override
        public String toStringUtf8() {
            return String.valueOf(value);
        }

        @Override
        public int hashCode() {
            return value;
        }
    }

    static class LongByteArray extends LiteralByteArray {
        private long value;
        private volatile byte[] raw;

        public LongByteArray(long v) {
            super(Bytes.toBytes(v));
            this.value = v;
        }

        @Override
        public byte[] array() {
            if (raw == null) {
                raw = Bytes.toBytes(value);
            }
            return raw;
        }

        @Override
        public int size() {
            return Bytes.SIZEOF_LONG;
        }

        @Override
        public int compareTo(ByteArray other) {
            if (other instanceof LongByteArray) {
                return Long.compare(this.value, ((LongByteArray) other).value);
            } else {
                return super.compareTo(other);
            }
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof LongByteArray) {
                return this.value == ((LongByteArray) obj).value;
            } else {
                return super.equals(obj);
            }
        }

        @Override
        public String toStringUtf8() {
            return String.valueOf(value);
        }

        @Override
        public int hashCode() {
            return (int)(value ^ (value >>> 32));
        }
    }
}
