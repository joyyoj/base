package yidian.common.base;

import com.google.common.base.Function;
import com.google.common.base.Predicate;

import java.io.Serializable;
import java.util.NoSuchElementException;
import java.util.Objects;

// a wrapper for object.
public class Value<T> implements Serializable {
    private static Value EMPTY = new Value();

    private final T value;

    private Value() {
        this(null);
    }

    private Value(T value) {
        this.value = value;
    }

    public static <T> Value<T> absent() {
        return EMPTY;
    }

    public static <T> Value<T> of(T var) {
        if (var == null) {
            return EMPTY;
        } else {
            return new Value(var);
        }
    }

    public boolean isAbsent() {
        return value == null;
    }

    public boolean isPresent() {
        return !isAbsent();
    }

    public T get() {
        if (value == null) {
            throw new NoSuchElementException("No value present");
        }
        return value;
    }

    // return value without check.
    @Deprecated
    public T value() {
        return value;
    }

    // functional function ===============

    public T orElse(T other) {
        return value != null ? value : other;
    }

    public <U> Value<U> map(Function<? super T, ? extends U> mapper) {
        Objects.requireNonNull(mapper);
        if (!isPresent())
            return absent();
        else {
            return of(mapper.apply(value));
        }
    }

    public Value<T> filter(Predicate<T> predicate) {
        Objects.requireNonNull(predicate);
        if (isPresent() && predicate.apply(value)) {
            return this;
        } else {
            return EMPTY;
        }
    }

    // hashcode and equals ==========

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (!(obj instanceof Value)) {
            return false;
        }

        Value<?> other = (Value<?>) obj;
        return Objects.equals(value, other.value);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value);
    }

    @Override
    public String toString() {
        return value != null
                ? String.format("Value[%s]", value)
                : "Value.empty";
    }
}
