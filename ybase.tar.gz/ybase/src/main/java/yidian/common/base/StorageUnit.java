package yidian.common.base;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum StorageUnit {
    B("B", 1L),
    KB("KB", 1L << 10),
    MB("MB", 1L << 20),
    GB("GB", 1L << 30),
    TB("TB", 1L << 40),
    PB("PB", 1L << 50),
    EB("EB", 1L << 60),
    ;

    private final long divider; // divider of BASE unit
    private final String name;

    StorageUnit(String name, long divider) {
        this.name = name;
        this.divider = divider;
    }

    public long toBytes(long value) {
        return value * divider;
    }

    /**
     * parseFrom string. like '5KB', '6MB'
     * @param value
     * @return
     */
    public static long parseFrom(String value) {
        Pattern pattern = Pattern.compile("(\\d+)(\\S+)");
        Matcher matcher = pattern.matcher(value);
        if (matcher.matches()) {
            String unit = matcher.group(2);
            boolean isBit = unit.endsWith("b");
            if (isBit) {
                unit = unit.substring(0, unit.length() - 1) + "B";
            }

            StorageUnit storageUnit = StorageUnit.valueOf(unit);
            long bytes = storageUnit.toBytes(Long.parseLong(matcher.group(1)));
            return isBit ? bytes / 8 : bytes;
        }
        return 0;
    }
}

