package yidian.common.base;

import com.google.common.base.Optional;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * utils for date.
 */
public class DateUtils {
    private static final Map<Pattern, String> DATE_FORMAT_REGEXPS = new LinkedHashMap<Pattern, String>() {{
        putPattern("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd HH:mm:ss");
        putPattern("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}\\s[+-]\\d{4}$", "yyyy-MM-dd HH:mm:ss ZZZZZ");
        putPattern("^\\d{8}$", "yyyyMMdd");
        putPattern("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
        putPattern("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
        putPattern("^\\d{1,2}/\\d{1,2}/\\d{4}$", "MM/dd/yyyy");
        putPattern("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
        putPattern("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
        putPattern("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
        putPattern("^\\d{12}$", "yyyyMMddHHmm");
        putPattern("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
        putPattern("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$", "dd-MM-yyyy HH:mm");
        putPattern("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}$", "yyyy-MM-dd HH");
        putPattern("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy-MM-dd HH:mm");
        putPattern("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$", "MM/dd/yyyy HH:mm");
        putPattern("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy/MM/dd HH:mm");
        putPattern("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMM yyyy HH:mm");
        putPattern("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMMM yyyy HH:mm");
        putPattern("^\\d{14}$", "yyyyMMddHHmmss");
        putPattern("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
        putPattern("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd-MM-yyyy HH:mm:ss");
        putPattern("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM/dd/yyyy HH:mm:ss");
        putPattern("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy/MM/dd HH:mm:ss");
        putPattern("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMM yyyy HH:mm:ss");
        putPattern("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMMM yyyy HH:mm:ss");
    }

        private void putPattern(String pattern, String dateTimeFormat) {
            put(Pattern.compile(pattern), dateTimeFormat);
        }
    };

    public static final String DEFAULT_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final Pattern DEFAULT_DATETIME_PATTERN = Pattern.compile(
            "^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$");

    /**
     * Determine SimpleDateFormat pattern matching with the given date string.
     * Returns absent if format is unknown. You can simply extend DateUtil with more formats if needed.
     * @param dateString The date string to determine the SimpleDateFormat pattern for.
     * @return The matching SimpleDateFormat pattern, or null if format is unknown.
     */
    private static Optional<String> determineDateFormat(String dateString) {
        if (dateString == null) {
            return Optional.absent();
        }
        for (Map.Entry<Pattern, String> entry : DATE_FORMAT_REGEXPS.entrySet()) {
            if (entry.getKey().matcher(dateString.toLowerCase()).matches()) {
                return Optional.of(entry.getValue());
            }
        }
        return Optional.absent();
    }

    // freqInSecond should < 1 day
    public static long floorTimestamp(long timestamp, int freq, TimeUnit timeUnit,
                                      TimeZone timeZone) {
        Calendar calendar = Calendar.getInstance(timeZone);
        calendar.setTimeInMillis(timestamp);
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        long startTime = calendar.getTimeInMillis();

        return timestamp - (timestamp - startTime) % timeUnit.toMillis(freq);
    }

    /**
     * 根据周期,timestamp 向下取整. by timezone default
     */
    public static long floorTimestamp(long timestamp, int freq, TimeUnit timeUnit) {
        return floorTimestamp(timestamp, freq, timeUnit, TimeZone.getDefault());
    }

    /**
     * 尝试确定日期格式,返回timestamp,相对比较耗时.
     * 在pattern确定的情况下,使用toTimestamp(dateTime, pattern)
     */
    public static long toTimestamp(String dateTime) {
        Optional<String> pattern = determineDateFormat(dateTime);

        if (pattern.isPresent()) {
            return toTimestamp(dateTime, pattern.get());
        } else {
            return 0;
        }
    }

    /**
     * @return timestamp in milli, 0 if failed
     */
    public static long toTimestamp(String dateTime, String pattern) {
        try {
            SimpleDateFormat sd = new SimpleDateFormat(pattern, Locale.CHINA);

            return sd.parse(dateTime).getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    public static String toDateTime(long timestamp) {
        return toDateTime(timestamp, DEFAULT_DATETIME_FORMAT);
    }

    public static String toDateTime(long timestamp, String pattern) {
        SimpleDateFormat sd = new SimpleDateFormat(pattern, Locale.CHINA);

        return sd.format(new Date(timestamp));
    }

    // 转换日期格式为yyyy-MM-dd HH:mm:ss格式.
    public static String formatDateTime(String dateTime) {
        return formatDateTime(dateTime, DEFAULT_DATETIME_FORMAT);
    }

    // 将日期转换到固定格式的日志格式
    public static String formatDateTime(String dateTime, String pattern) {
        return toDateTime(toTimestamp(dateTime), pattern);
    }

//    // 兼容错误格式的日志格式
//    @Deprecated
//    public static String tryFormatDateTime(String dateTime) {
//        if (DEFAULT_DATETIME_PATTERN.matcher(dateTime).matches()) {
//            return dateTime;
//        }
//        int index = dateTime.lastIndexOf("  ");
//        // 2014-08-21 21 0000  0000
//        if (index != -1 && index + 6 == dateTime.length()) {
//            boolean allDigit = true;
//            String end = "";
//            for (int i = index + 2; i < dateTime.length(); ++i) {
//                if (!Character.isDigit(dateTime.charAt(i))) {
//                    allDigit = false;
//                    break;
//                }
//                end += dateTime.charAt(i);
//            }
//            if (allDigit) {
//                dateTime = dateTime.substring(0, index) + " +" + end;
//            }
//        }
//        return toDateTime(toTimestamp(dateTime));
//    }
}
