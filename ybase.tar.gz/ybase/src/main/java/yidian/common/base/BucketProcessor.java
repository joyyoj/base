package yidian.common.base;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// 分批处理数据,在批量rpc请求时,可以将一个请求拆分为多次请求,以免一次请求过大
public class BucketProcessor<Value> implements Closeable {
    public static Reducer EMPTY_REDUCER = (values) -> {};
    protected final int bucketSize;
    protected final List<Value> buckets;
    protected List<Value> bufferValue = new ArrayList<>();
    protected Reducer<Value> reducer;

    public BucketProcessor(int bucketSize) {
        this(EMPTY_REDUCER, bucketSize);
    }

    public BucketProcessor(Reducer<Value> reducer, int bucketSize) {
        this.bucketSize = bucketSize;
        buckets = new ArrayList<>(bucketSize);
        setReducer(reducer);
    }

    public BucketProcessor<Value> setReducer(Reducer<Value> reducer) {
        this.reducer = reducer;
        return this;
    }

    public void process(List<Value> values) throws Exception {
        bufferValue = values;

        if (isFull()) {
            process(values.iterator());
        } else {
            batchExecAndReset(values);
        }
    }

    public void addToBuffer(Value value) throws Exception {
        bufferValue.add(value);
        if (isFull()) {
            batchExecAndReset(bufferValue);
        }
    }

    @Override
    public void close() throws IOException {
        try {
            clearBuffer();
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    public void clearBuffer() throws Exception {
        if (!bufferValue.isEmpty()) {
            batchExecAndReset(bufferValue);
        }
    }

    public void process(Iterator<Value> iterator) throws Exception {
        while (iterator.hasNext()) {
            Value value = iterator.next();

            buckets.add(value);
            if (buckets.size() >= bucketSize) {
                batchExecAndReset(buckets);
            }
        }
        if (!buckets.isEmpty()) {
            batchExecAndReset(buckets);
        }
    }

    protected boolean isFull() {
        return bufferValue.size() > bucketSize;
    }

    private void batchExecAndReset(List<Value> values) throws Exception {
        batchExec(values);
        values.clear();
    }

    protected void batchExec(List<Value> values) throws Exception {
        reducer.reduce(values);
    }

    public interface Reducer<Value> {
        void reduce(List<Value> values) throws Exception;
    }
}
