package yidian.common.base;

import com.google.common.base.Charsets;
import com.google.protobuf.ByteString;
import yidian.common.base.ByteArrays.LiteralByteArray;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * Immutable byte array, ByteStringRef
 */
public abstract class ByteArray implements Comparable<ByteArray>, Iterable<Byte>, Serializable {
    public static final byte[] EMPTY_BYTE = new byte[0];
    private static final ByteArray EMPTY = new LiteralByteArray(EMPTY_BYTE);
    private static final char[] HEX_CHARS_UPPER = {
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
    };
    private int hash; //    Cache the hash code for the bytearray, Default to 0

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ByteArray)) {
            return false;
        }
        final ByteArray other = (ByteArray) obj;

        int cmp = compareTo(other);
        return cmp == 0;
    }

    @Override
    public int compareTo(ByteArray other) {
        Objects.requireNonNull(other);

        if (this.array() == other.array() && this.offset() == other.offset() && this.size() == other.size()) {
            return 0;
        }

        int len1 = this.size();
        int len2 = other.size();
        int lim = Math.min(len1, len2);
        byte v1[] = this.array();
        byte v2[] = other.array();

        int offset1 = this.offset();
        int offset2 = other.offset();

        while (lim-- > 0) {
            byte c1 = v1[offset1++];
            byte c2 = v2[offset2++];

            if (c1 != c2) {
                return (c1 & 0xFF) - (c2 & 0xFF); // "promote" to unsigned.
            }
        }
        return len1 - len2;
    }

    /**
     * @return bytes that can access directly. get or copy bytes internal.
     */
    @Deprecated
    public byte[] getBytes() {
        return getOrCopyBytes();
    }

    /**
     *
     * @return byte array with length=size(), means offset eq 0.
     */
    public byte[] getOrCopyBytes() {
        byte[] res = array();

        if (offset() == 0 && res.length == size()) {
            return res;
        } else {
            return copyBytes();
        }
    }

    /**
     * @param pos position start from offset(). offset() <= pos < offset() + size().
     */
    @Deprecated
    public byte byteAt(int pos) {
        return array()[pos];
    }

    public byte[] copyBytes() {
        byte[] out = new byte[size()];

        System.arraycopy(array(), offset(), out, 0, out.length);
        return out;
    }

    /**
     * @return raw bytes, should access with offset and size.
     */
    public abstract byte[] array();

    public int offset() {
        return 0;
    }

    public int size() {
        return array().length;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public int hashCode() {
        int h = hash;
        byte[] value = array();

        if (h == 0 && size() > 0) {
            int result = 1;

            for (int i = offset(), max = offset() + size(); i < max; ++i) {
                result = 31 * result + value[i];
            }
            h = result;
            hash = h;
        }
        return h;
    }

    @Override
    public String toString() {
        return toStringUtf8();
    }

    public String toStringUtf8() {
        return new String(array(), offset(), size(), Charsets.UTF_8);
    }

    public ByteBuffer toByteBuffer() {
        return ByteBuffer.wrap(array(), offset(), size());
    }

    public ByteString toByteString() {
        return ByteString.copyFrom(array(), offset(), size());
    }

    /**
     * Write a printable representation of a byte array. Non-printable
     * characters are hex escaped in the format \\x%02X, eg:
     * \x00 \x05 etc
     *
     * @return string output
     */
    public String toStringBinary() {
        final byte[] b = array();
        int off = offset();
        int len = size();

        StringBuilder result = new StringBuilder();

        // Just in case we are passed a 'len' that is > buffer length...
        if (off >= b.length) {
            return result.toString();
        }
        if (off + len > b.length) {
            len = b.length - off;
        }
        for (int i = off; i < off + len; ++i) {
            int ch = b[i] & 0xFF;
            if (ch >= ' ' && ch <= '~' && ch != '\\') {
                result.append((char) ch);
            } else {
                result.append("\\x");
                result.append(HEX_CHARS_UPPER[ch / 0x10]);
                result.append(HEX_CHARS_UPPER[ch % 0x10]);
            }
        }
        return result.toString();
    }

    @Override
    public Iterator<Byte> iterator() {
        return new LiteralByteIterator();
    }

    private class LiteralByteIterator implements Iterator<Byte> {
        private int position;
        private final byte[] value;
        private final int limit;

        private LiteralByteIterator() {
            this.value = array();
            this.position = offset();
            this.limit = size();
        }

        public boolean hasNext() {
            return this.position < this.limit;
        }

        public Byte next() {
            return Byte.valueOf(this.nextByte());
        }

        public byte nextByte() {
            try {
                return value[this.position++];
            } catch (ArrayIndexOutOfBoundsException var2) {
                throw new NoSuchElementException(var2.getMessage());
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public static ByteArray empty() {
        return EMPTY;
    }

    public static ByteArray copyFrom(ByteBuffer data) {
        byte[] bytes = new byte[data.remaining()];

        System.arraycopy(data.array(), data.arrayOffset() + data.position(),
                bytes, 0, data.remaining());
        return new LiteralByteArray(bytes);
    }

    public static ByteArray copyFromUtf8(String value) {
        return copyFrom(value, Charsets.UTF_8);
    }

    public static ByteArray copyFrom(String value, Charset charset) {
        return new LiteralByteArray(value.getBytes(charset));
    }

    public static ByteArray ref(byte[] bytes) {
        return new LiteralByteArray(bytes);
    }

    public static ByteArray ref(byte[] bytes, int offset, int len) {
        return new ByteArrays.ByteRef(bytes, offset, len);
    }

    public static ByteArray ref(ByteBuffer byteBuffer) {
        return new ByteArrays.ByteRef(byteBuffer.array(),
                byteBuffer.arrayOffset() + byteBuffer.position(),
                byteBuffer.remaining());
    }

    @Deprecated
    public static ByteArray intBytes(int v) {
        return new ByteArrays.IntByteArray(v);
    }

    @Deprecated
    public static ByteArray longBytes(long v) {
        return new ByteArrays.LongByteArray(v);
    }
}
