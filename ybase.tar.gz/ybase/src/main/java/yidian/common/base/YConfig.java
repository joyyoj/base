package yidian.common.base;

import com.google.common.base.Optional;
import com.google.common.base.Preconditions;
import com.typesafe.config.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.util.*;

/**
 * directly ref typesafe config.
 * YConfig is immutable
 * 对于未设置的参数,未提供get(key, default)这样的方法,如果找不到,会抛出ConfigException.Missing
 * 如果不想抛异常,可以使用getOptXX的方法.
 * see https://github.com/typesafehub/config#how-to-handle-defaults
 */
public class YConfig {
    private static final Logger logger = LoggerFactory.getLogger(YConfig.class);
    public static final String KW_INCLUDE_HADOOP_CONF = "include_hadoop_xml";

    private static YConfig empty = new YConfig(ConfigFactory.empty());
    private Config config;

    public static class Vars implements Serializable {
        String varName;
        Object defaultValue; // only primitive type supported

        Vars(String name) {
            this.varName = name;
        }

        public static Vars of(String name, Object defaultValue) {
            Vars var = new Vars(name);
            var.defaultValue = defaultValue;
            return var;
        }

        public Object getDefaultValue() {
            return this.defaultValue;
        }

        public String name() {
            return varName;
        }

        public PrimitiveValue readFrom(Map map) {
            Object v = map.get(name());

            if (v == null) {
                v = defaultValue;
            }
            return new PrimitiveValue(v);
        }
    }

    public static class Builder {
        public Properties properties = new Properties();

        public Builder load(InputStream inputStream) throws IOException {
            properties.load(inputStream);
            return this;
        }

        public Builder set(String key, String v) {
            properties.put(key, v);
            return this;
        }

        public Builder set(String key, Object v) {
            return set(key, String.valueOf(v));
        }

        public YConfig build() {
            Config config = ConfigFactory.parseProperties(properties);
            return YConfig.create(config);
        }
    }

    public static Builder newBuiler() {
        return new Builder();
    }

    public static YConfig create(Map<String, ? extends Object> map) {
        Map<String, Object> after = new TreeMap<>();

        for (Map.Entry entry : map.entrySet()) {
            after.put(normalizeKey((String) entry.getKey()), entry.getValue());
        }
        Set<String> toRemoved = new HashSet<>();
        String prev = null;

        for (Map.Entry<String, Object> entry : after.entrySet()) {
            if (prev != null && entry.getKey().startsWith(prev) &&
                    entry.getKey().charAt(prev.length()) == '.') {
               toRemoved.add(prev);
            }
            prev = entry.getKey();
        }
        for (String key : toRemoved) {
            after.remove(key);
        }
        return new YConfig(ConfigFactory.parseMap(after));
    }

    /**
     * load will normalize key.
     *
     * @param entries
     * @return
     */
    public static YConfig create(Iterator<Map.Entry<String, String>> entries) {
        Properties map = new Properties();

        while (entries.hasNext()) {
            Map.Entry<String, ? extends Object> entry = entries.next();

            if (entry.getValue() == null) {
                logger.warn("ignore " + entry.getKey() + " for its value is null");
            } else {
                map.put(normalizeKey(entry.getKey()), entry.getValue());
            }
        }
        Config config = ConfigFactory.parseProperties(map);

        return new YConfig(config);
    }

    public static YConfig loadFile(String resourceName) {
        InputStream in;

        try {
            in = new FileInputStream(resourceName);
        } catch (FileNotFoundException e) {
            in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceName);
            Preconditions.checkArgument(in != null, "loadFile failed from " + resourceName);
        }
        try (InputStreamReader reader = new InputStreamReader(in)) {
            Config config = ConfigFactory.parseReader(reader);

            return new YConfig(config);
        } catch (IOException ie) {
            throw new IllegalStateException("failed to close", ie);
        }
    }

    public static YConfig load() {
        return create(ConfigFactory.load());
    }

    public YConfig withFallback(YConfig other) {
        YConfig merge = YConfig.create(config.withFallback(other.get()));
        return merge;
    }

    public static YConfig create(Config conf) {
        return new YConfig(conf);
    }

    public static YConfig empty() {
        return empty;
    }

    private YConfig(Config config) {

        this.config = config;
        if (config.hasPath(KW_INCLUDE_HADOOP_CONF)) {
            List<String> xmls = config.getStringList(KW_INCLUDE_HADOOP_CONF);
            ClassLoader clsLoader = Thread.currentThread().getContextClassLoader();
            for (String xml : xmls) {
                YConfig other;

                if (new File(xml).exists()) {
                    other = YConfig.createFromHadoopConf(new File(xml));
                } else {
                    try (InputStream is = clsLoader.getResourceAsStream(xml)) {
                        other = YConfig.createFromHadoopConf(is);
                    } catch (IOException ie) {
                        logger.error("failed to close " + xml, ie);
                        other = empty();
                    }
                }
                this.config = this.config.withFallback(other.config);
            }
        }
    }

    // return config at path
    public YConfig getConfig(String path) {
        return new YConfig(get().getConfig(path));
    }

    public Map<String, String> toMap() {
        Map<String, String> properties = new HashMap<>();

        for (Map.Entry<String, ConfigValue> entry : config.entrySet()) {
            if (entry.getValue().valueType() == ConfigValueType.OBJECT) {
                properties.put(entry.getKey(), entry.getValue().render());
            } else if (entry.getValue().valueType() != ConfigValueType.NULL) {  // ignore null
                properties.put(entry.getKey(), entry.getValue().unwrapped().toString());
            }
        }
        return properties;
    }

    public Config get() {
        return config;
    }

    @Override
    public String toString() {
        return config.root().render(ConfigRenderOptions.defaults().setComments(false));
    }

    public String get(Vars var) {
        if (!config.hasPath(var.name())) {
            return PrimitiveValue.of(var.defaultValue).asString();
        } else {
            return config.getString(var.name());
        }
    }

    public boolean hasPath(String path) {
        return config.hasPath(path);
    }

    public int getInt(Vars var) {
        if (!config.hasPath(var.name())) {
            return PrimitiveValue.of(var.getDefaultValue()).asInt();
        } else {
            return config.getInt(var.name());
        }
    }

    public long getLong(Vars var) {
        if (!config.hasPath(var.name())) {
            return PrimitiveValue.of(var.getDefaultValue()).asLong();
        } else {
            return config.getLong(var.name());
        }
    }

    public boolean getBoolean(Vars var) {
        if (!config.hasPath(var.name())) {
            return PrimitiveValue.of(var.getDefaultValue()).asBoolean();
        } else {
            return config.getBoolean(var.name());
        }
    }

    public double getDouble(Vars var) {
        if (!config.hasPath(var.name())) {
            return PrimitiveValue.of(var.getDefaultValue()).asDouble();
        } else {
            return config.getDouble(var.name());
        }
    }

    public Optional<String> getOptString(String path) {
        if (config.hasPath(path)) {
            return Optional.of(config.getString(path));
        } else {
            return Optional.absent();
        }
    }

    public Optional<Boolean> getOptBoolean(String path) {
        if (config.hasPath(path)) {
            Boolean obj = config.getBoolean(path);
            return Optional.of(obj);
        } else {
            return Optional.absent();
        }
    }

    public Optional<Integer> getOptInt(String path) {
        if (config.hasPath(path)) {
            return Optional.of(config.getInt(path));
        } else {
            return Optional.absent();
        }
    }

    public Optional<Long> getOptLong(String path) {
        if (config.hasPath(path)) {
            return Optional.of(config.getLong(path));
        } else {
            return Optional.absent();
        }
    }

    public Optional<Double> getOptDouble(String path) {
        if (config.hasPath(path)) {
            return Optional.of(config.getDouble(path));
        } else {
            return Optional.absent();
        }
    }

    public Optional<YConfig> getOptConfig(String path) {
        if (config.hasPath(path)) {
            return Optional.of(YConfig.create(config.getConfig(path)));
        } else {
            return Optional.absent();
        }
    }

    /**
     * YConfig is immutable. so withValue will return a new object.
     */
    public YConfig withValue(String path, Object v) {
        return new YConfig(config.withValue(path, ConfigValueFactory.fromAnyRef(v)));
    }

    // load from resource.
    public static YConfig createFromHadoopConf(String xml) {
        try (InputStream xmlStream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream(xml)) {
            return createFromHadoopConf(xmlStream);
        } catch (IOException e) {
            logger.error("failed to close ", e);
            return YConfig.empty();
        }
    }

    public static YConfig createFromHadoopConf(InputStream xmlStream) {
        if (xmlStream == null) {
            return new YConfig(ConfigFactory.empty());
        } else {
            Document document = getXMLFromString(xmlStream);

            return createFromHadoopConf(document);
        }
    }

    // load from file.
    public static YConfig createFromHadoopConf(File file) {
        try (FileInputStream fileIn = new FileInputStream(file)) {
            return createFromHadoopConf(fileIn);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("file not found " + file.getAbsolutePath(), e);
        } catch (IOException ie) {
            logger.error("failed to close " + file.getPath(), ie);
            return empty();
        }
    }

    // Notice: 这里使用Properties而不是Map,原因是可能出现a=b, a.c=z;此时a既是key,也是a.c的parent.
    private static YConfig createFromHadoopConf(Document document) {
        Properties props = new Properties();
        document.getDocumentElement().normalize();
        NodeList nodeList = document.getElementsByTagName("property");

        for (int i = 0; i < nodeList.getLength(); ++i) {
            Node node = nodeList.item(i);
            Element element = (Element) node;
            Node name = element.getElementsByTagName("name").item(0);
            Node value = element.getElementsByTagName("value").item(0);

            if (name != null) {
                props.put(normalizeKey(name.getTextContent()), value == null ? "" : value.getTextContent());
            }
        }

        return new YConfig(ConfigFactory.parseProperties(props));
    }

    private static Document getXMLFromString(InputStream xmlStream) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory
                    .newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();

            return builder.parse(new InputSource(xmlStream));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    // normalize string that quote still not open, like 1) "key or 2) key"
    static String normalizeKey(String key) {
        boolean startWithQuote = key.startsWith("\"");
        boolean endWithQuote = key.endsWith("\"");

        if (startWithQuote && !endWithQuote) {
            return key.substring(1);
        } else if (!startWithQuote && endWithQuote) {
            return key.substring(0, key.length() - 1);
        } else {
            return key;
        }
    }
}

