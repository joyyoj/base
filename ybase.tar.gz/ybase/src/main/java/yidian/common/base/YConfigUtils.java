package yidian.common.base;

import com.google.protobuf.Descriptors;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.FieldDescriptor.JavaType;
import com.google.protobuf.MapEntry;
import com.google.protobuf.Message;
import com.google.protobuf.WireFormat;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigValue;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import static com.google.protobuf.Descriptors.FieldDescriptor.JavaType.*;

/**
 * Created by sunshangchun on 15/12/28.
 */
public class YConfigUtils {
    public static <T extends Message> T toMessage(Config config, String className) {
        try {
            Class<?> protoClass = Class.forName(className);

            return toMessage(config, (Class<T>) protoClass);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public static <T extends Message> T toMessage(Config config, Class<T> protoClass) {
        try {
            Method main = protoClass.getDeclaredMethod("newBuilder");
            Message.Builder builder = (Message.Builder) main.invoke(null);

            return (T) setMessage(config, builder);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public static <T extends Message> T toMessage(YConfig config, String className) {
        return toMessage(config.get(), className);
    }

    public static <T extends Message> T toMessage(YConfig config, Class<T> protoClass) {
        return toMessage(config.get(), protoClass);
    }

    static Message setMessage(Config config, Message.Builder msg) {
        Descriptors.Descriptor descriptor = msg.getDescriptorForType();

        for (FieldDescriptor fieldDescriptor : descriptor.getFields()) {
            JavaType javaType = fieldDescriptor.getJavaType();
            String name = fieldDescriptor.getName();

            if (!config.hasPath(name)) {
                continue;
            }
            if (fieldDescriptor.isRepeated()) {
                if (javaType == BOOLEAN) {
                    List<Boolean> v = config.getBooleanList(name);

                    for (Boolean b : v) {
                        msg.addRepeatedField(fieldDescriptor, b);
                    }
                } else if (javaType == DOUBLE) {
                    List<Double> v = config.getDoubleList(name);

                    for (Double d : v) {
                        msg.addRepeatedField(fieldDescriptor, d);
                    }
                } else if (javaType == STRING) {
                    List<String> v = config.getStringList(name);

                    for (String s : v) {
                        msg.addRepeatedField(fieldDescriptor, s);
                    }
                } else if (javaType == INT) {
                    List<Integer> v = config.getIntList(name);

                    for (Integer i : v) {
                        msg.addRepeatedField(fieldDescriptor, i);
                    }
                } else if (javaType == LONG) {
                    List<Long> v = config.getLongList(name);

                    for (Long l : v) {
                        msg.addRepeatedField(fieldDescriptor, l);
                    }
                } else if (javaType == MESSAGE && !fieldDescriptor.isMapField()) {
                    List<? extends Config> v = config.getConfigList(name);
                    int i = 0;

                    for (Config c : v) {
                        Message.Builder fieldBuilder =
                                msg.getRepeatedFieldBuilder(fieldDescriptor, i++);
                        Message field = setMessage(c, fieldBuilder);

                        msg.addRepeatedField(fieldDescriptor, field);
                    }
                } else if (fieldDescriptor.isMapField()) {
                    Config child = config.getConfig(fieldDescriptor.getName());

                    for (Map.Entry<String, ConfigValue> entry : child.entrySet()) {
                        final MapEntry<String, String> mapEntry =
                                MapEntry.newDefaultInstance(descriptor,
                                        WireFormat.FieldType.STRING, entry.getKey(),
                                        WireFormat.FieldType.STRING,
                                        entry.getValue().unwrapped().toString());
                        msg.addRepeatedField(fieldDescriptor, mapEntry);
                    }
                    try {
                        // TODO call getMutableXXX which trigger set MapField's mode to Map,
                        // so that print msg cause no error.
                        String methodName = "getMutable" + Character.toUpperCase(name.charAt(0))
                                + name.substring(1);

                        Method method = msg.getClass().getMethod(methodName);
                        method.invoke(msg);
                    } catch (Exception e) {
                        // ignore
                    }
                } else {
                    throw new UnsupportedOperationException("not supported " + name
                            + " " + fieldDescriptor.getJavaType());
                }
            } else {
                Object v;

                if (javaType == BOOLEAN) {
                    v = config.getBoolean(name);
                    msg.setField(fieldDescriptor, v);
                } else if (javaType == DOUBLE) {
                    v = config.getDouble(name);
                    msg.setField(fieldDescriptor, v);
                } else if (javaType == STRING) {
                    v = config.getString(name);
                    msg.setField(fieldDescriptor, v);
                } else if (javaType == INT) {
                    v = config.getInt(name);
                    msg.setField(fieldDescriptor, v);
                } else if (javaType == LONG) {
                    v = config.getLong(name);
                    msg.setField(fieldDescriptor, v);
                } else if (javaType == MESSAGE) {
                    Config child = config.getConfig(name);
                    Message.Builder fieldBuilder = msg.newBuilderForField(fieldDescriptor);
                    Message field = setMessage(child, fieldBuilder);

                    msg.setField(fieldDescriptor, field);
                } else if (fieldDescriptor.getJavaType() == ENUM) {
                    String enumV = config.getString(name);
                    Descriptors.EnumValueDescriptor desc = descriptor
                            .findEnumTypeByName(fieldDescriptor.getEnumType().getName())
                            .findValueByName(enumV);

                    msg.setField(fieldDescriptor, desc);
                } else {
                    throw new UnsupportedOperationException("not supported " + name
                            + " " + fieldDescriptor.getJavaType());
                }
            }
        }
        return msg.build();
    }
}
