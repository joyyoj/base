package yidian.common.base;

/**
 * boolean, short, int, long, float, double, string.
 */
public class PrimitiveValue<T> {
    private static PrimitiveValue EMPTY_VALUE = new PrimitiveValue(null);
    private final T var;

    PrimitiveValue(T var) {
        this.var = var;
    }

    public static <T> PrimitiveValue<T> of(T v) {
        return new PrimitiveValue(v);
    }

    public static PrimitiveValue empty() {
        return EMPTY_VALUE;
    }

    public T value() {
        return var;
    }

    public Boolean asBoolean() {
        if (var == null) {
            return null;
        } else if (var instanceof Boolean) {
            return (Boolean) var;
        } else {
            return Boolean.parseBoolean(String.valueOf(var).toUpperCase());
        }
    }

    public Short asShort() {
        if (var == null) {
            return null;
        } else {
            return (short) toLong(var);
        }
    }

    public Integer asInt() {
        if (var == null) {
            return null;
        } else {
            return (int) toLong(var);
        }
    }

    public Long asLong() {
        if (var == null) {
            return null;
        } else {
            return toLong(var);
        }
    }

    public Float asFloat() {
        if (var == null) {
            return null;
        } else {
            return (float) toDouble(var);
        }
    }

    public Double asDouble() {
        if (var == null) {
            return null;
        } else {
            return toDouble(var);
        }
    }

    public String asString() {
        if (var == null) {
            return null;
        } else if (var instanceof String) {
            return (String) var;
        } else {
            return String.valueOf(var);
        }
    }

    private long toLong(Object number) {
        if (number instanceof Short) {
            return (long) (short) number;
        } else if (number instanceof Integer) {
            return (long) (int) number;
        } else if (number instanceof Long) {
            return (Long) number;
        } else if (number instanceof Float) {
            return (long) (float) (Float) number;
        } else if (number instanceof Double) {
            return (long) (double) (Double) number;
        } else {
            return Long.parseLong(String.valueOf(number));
        }
    }

    private double toDouble(Object number) {
        if (number instanceof Float) {
            return (float) (Float) number;
        } else if (number instanceof Double) {
            return (Double) number;
        } else if (number instanceof Short) {
            return (short) (Short) number;
        } else if (number instanceof Integer) {
            return (int) (Integer) var;
        } else if (number instanceof Long) {
            return (long) (Long) var;
        } else {
            return Double.parseDouble(String.valueOf(number));
        }
    }
}
