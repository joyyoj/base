package yidian.common.base;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 合并相同的key, 算法的正确性要求输入数据保证相同key连续.
 */
public class KeyGrouper<K extends Comparable<K>, V> implements Closeable {
    private final Reducer<K, V> reducer;
    private final List<V> values = new ArrayList<>();
    int emitInterval = 0;
    private boolean isFirst = true;
    private K curKey = null;

    public KeyGrouper(Reducer<K, V> reducer) {
        this.reducer = reducer;
    }

    /**
     * set max emit interval.
     */
    public KeyGrouper<K, V> setEmitInterval(int emitInterval) {
        this.emitInterval = emitInterval;
        return this;
    }

    public void add(K k, V v) throws Exception {
        if (isFirst) {
            isFirst = false;
            this.curKey = k;
            this.values.add(v);
        } else if (k.compareTo(curKey) != 0 ||
                (emitInterval > 0 && values.size() >= emitInterval)) {
            reducer.reduce(curKey, values);
            values.clear();
            curKey = k;
            values.add(v);
        } else {
            values.add(v);
        }
    }

    public void cleanUp() throws Exception {
        if (!values.isEmpty()) {
            reducer.reduce(curKey, values);
            values.clear();
        }
    }

    @Override
    public void close() throws IOException {
        try {
            cleanUp();
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    public interface Reducer<K, V> {
        void reduce(K key, List<V> values) throws Exception;
    }
}
