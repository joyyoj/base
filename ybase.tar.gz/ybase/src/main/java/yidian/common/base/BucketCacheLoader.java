package yidian.common.base;

import com.google.common.cache.CacheLoader;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;

import java.util.*;

/**
 * Load values in a batch way
 */
public abstract class BucketCacheLoader<K, V> extends CacheLoader<K, V> {
    private int batchSize = 200;
    public BucketCacheLoader() {
    }

    public BucketCacheLoader(int batchSize) {
        this.batchSize = batchSize;
    }

    private<T> List<T> toList(Iterable<? extends T> keys) {
        List<T> output = new ArrayList<T>();
        for (T k : keys) {
            output.add(k);
        }
        return output;
    }

    @Override
    public Map<K, V> loadAll(Iterable<? extends K> keys) throws Exception {
        List<K> ids = toList(keys);
        Map<K, V> all = new HashMap<>();
        for (int i = 0, len = ids.size(); i < len; i += batchSize) {
            List<K> miniIds = new ArrayList<>(batchSize);
            for (int j = 0, maxj = Math.min(batchSize, len - i); j < maxj; ++j) {
                miniIds.add(ids.get(i + j));
            }
            all.putAll(this.loadAll(miniIds));
        }
        Map<K, V> result = new HashMap<K, V>(all);
        HashSet<K> need = new HashSet<K>(ids);
        Set<K> real = result.keySet();
        Set<K> missed = Sets.difference(need, real);
        for (K k : missed) {
            result.put(k, Null());
        }
        return result;
    }

    protected abstract Map<K, V> loadAll(List<K> keys) throws Exception;

    protected abstract V Null();

    @Override
    public V load(K k) throws Exception {
        if (k == null) {
            return Null();
        }
        V v = loadAll(ImmutableList.of(k)).get(k);
        if (v == null) {
            return Null();
        }
        return v;
    }
}

