package yidian.common.base;

import com.google.common.annotations.Beta;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.GsonBuilder;
import com.typesafe.config.*;

import java.io.Serializable;
import java.io.StringReader;

/**
 * Created by sunshangchun on 16/6/21.
 */
@Beta
public class Args implements Serializable {

    public static <T extends Args> T parse(YConfig config, Class<T> cls) {
        String json = config.get().root().render(ConfigRenderOptions.defaults().setJson(true));

        return new GsonBuilder()
                .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                .create()
                .fromJson(json, cls);
    }

    public YConfig toConfig() {
        String json = new GsonBuilder().disableHtmlEscaping().create().toJson(this);
        Config conf = ConfigFactory.parseReader(new StringReader(json),
                ConfigParseOptions.defaults().setSyntax(ConfigSyntax.JSON));

        return YConfig.create(conf);
    }

    @Override
    public String toString() {
       return new GsonBuilder()
               .setFieldNamingPolicy(getFieldNamingPolicy())
               .disableHtmlEscaping()
               .create().toJson(this);
    }

    protected FieldNamingPolicy getFieldNamingPolicy() {
       return FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES;
    }
}
