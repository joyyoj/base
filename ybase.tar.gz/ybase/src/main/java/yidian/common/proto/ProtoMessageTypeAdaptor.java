package yidian.common.proto;

import com.google.gson.*;
import com.google.protobuf.Message;
import com.google.protobuf.util.JsonFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Type;

/**
 * Created by sunshangchun on 16/9/27.
 */
public class ProtoMessageTypeAdaptor implements JsonSerializer<Message> {
    static final Logger logger = LoggerFactory.getLogger(ProtoMessageTypeAdaptor.class);
    final JsonParser jsonParser = new JsonParser();

    @Override
    public JsonElement serialize(Message message, Type type, JsonSerializationContext jsonSerializationContext) {
        try {
            return jsonParser.parse(JsonFormat.printer().usingProtoFieldName().print(message));
        } catch (Exception e) {
            logger.error("failed to serialize ", e);
            return null;
        }
    }
}
