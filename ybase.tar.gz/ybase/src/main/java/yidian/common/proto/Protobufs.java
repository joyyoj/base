package yidian.common.proto;

import com.google.common.annotations.Beta;
import com.google.gson.GsonBuilder;
import com.google.protobuf.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by sunshangchun on 16/6/16.
 */
public class Protobufs {
    private static final Logger LOG = LoggerFactory.getLogger(Protobufs.class);

    @SuppressWarnings("unchecked")
    public static <M extends Message> M parseFrom(Class<M> protoClass, byte[] messageBytes) {
        try {
            Method parseFrom = protoClass.getMethod("parseFrom", new Class[] { byte[].class });
            return (M)parseFrom.invoke(null, new Object[] { messageBytes });
        } catch (NoSuchMethodException e) {
            LOG.error("Could not find method parseFrom in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        } catch (IllegalAccessException e) {
            LOG.error("Could not access method parseFrom in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        } catch (InvocationTargetException e) {
            LOG.error("Error invoking method parseFrom in class " + protoClass, e);
        }

        return null;
    }

    public static DynamicMessage parseDynamicFrom(Class<? extends Message> protoClass, byte[] messageBytes) {
        try {
            return DynamicMessage.parseFrom(getMessageDescriptor(protoClass), messageBytes);
        } catch (InvalidProtocolBufferException e) {
            LOG.error("Protocol buffer parsing error in parseDynamicFrom", e);
        } catch(UninitializedMessageException ume) {
            LOG.error("Uninitialized Message error in parseDynamicFrom " + protoClass.getName(), ume);
        }

        return null;
    }

    public static Message.Builder getMessageBuilder(Class<? extends Message> protoClass) {
        if (protoClass == DynamicMessage.class) {
            return DynamicMessage.newBuilder(getMessageDescriptor(protoClass));
        }
        try {
            Method newBuilder = protoClass.getMethod("newBuilder", new Class[] {});
            return (Message.Builder) newBuilder.invoke(null, new Object[] {});
        } catch (NoSuchMethodException e) {
            LOG.error("Could not find method newBuilder in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        } catch (IllegalAccessException e) {
            LOG.error("Could not access method newBuilder in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        } catch (InvocationTargetException e) {
            LOG.error("Error invoking method newBuilder in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        }
    }

    public static Descriptors.Descriptor getMessageDescriptor(Class<? extends Message> protoClass) {
        try {
            Method getDescriptor = protoClass.getMethod("getDescriptor", new Class[] {});
            return (Descriptors.Descriptor)getDescriptor.invoke(null, new Object[] {});
        } catch (NoSuchMethodException e) {
            LOG.error("Could not find method getDescriptor in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        } catch (IllegalAccessException e) {
            LOG.error("Could not access method getDescriptor in class " + protoClass, e);
            throw new IllegalArgumentException(e);
        } catch (InvocationTargetException e) {
            LOG.error("Error invoking method getDescriptor in class " + protoClass, e);
        }

        return null;
    }

    /**
     * @return 返回有能力序列化包含Message成员的对象为json.
     */
    @Beta
    public static GsonBuilder createGsonBuilder() {
        return new GsonBuilder().registerTypeHierarchyAdapter(Message.class,
                new ProtoMessageTypeAdaptor());
    }
}
