package yidian.common.proto;

import com.google.common.base.Optional;
import com.google.protobuf.DescriptorProtos.DescriptorProto;
import com.google.protobuf.DescriptorProtos.FieldDescriptorProto;
import com.google.protobuf.DescriptorProtos.FileDescriptorProto;
import com.google.protobuf.DescriptorProtos.MessageOptions;
import com.google.protobuf.Descriptors;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;

import java.util.HashMap;
import java.util.Map;

/**
 * for dynamic create descri
 */
public class DescriptorWrapper {
    private final Descriptors.FileDescriptor fd;

    DescriptorWrapper(Descriptors.FileDescriptor fd) {
        this.fd = fd;
    }

    public Descriptors.FileDescriptor getFileDescriptor() {
        return fd;
    }

    public Optional<Descriptor> findDescriptor(String name) {
        for (Descriptor descriptor : fd.getMessageTypes()) {
            if (descriptor.getName().equals(name)) {
                return Optional.of(descriptor);
            }
        }
        return Optional.absent();
    }

    public Optional<MessageWrapper.Builder> newMessageBuilder(String name) {
        Optional<Descriptor> desc = findDescriptor(name);
        if (desc.isPresent()) {
            return Optional.of(new MessageWrapper.Builder(desc.get()));
        } else {
            return Optional.absent();
        }
    }

    public static class Builder {
        private final FileDescriptorProto.Builder fileBuilder = FileDescriptorProto.newBuilder();
        private DescriptorProto.Builder current;
        private Map<String, DescriptorProto.Builder> mapTypes = new HashMap<>();
        private int msgFieldNumber = 1;

        public DescriptorWrapper build() {
            try {
                Descriptors.FileDescriptor[] fds = new Descriptors.FileDescriptor[0];
                FileDescriptorProto fileProto;

                resetCurrent(null);
                fileProto = fileBuilder.build();
                return new DescriptorWrapper(Descriptors.FileDescriptor.buildFrom(fileProto, fds));
            } catch (Descriptors.DescriptorValidationException e) {
                throw new IllegalStateException(e);
            }
        }

        public Builder newMessage(String name) {
            resetCurrent(DescriptorProto.newBuilder().setName(name));
            return this;
        }

        private void resetCurrent(DescriptorProto.Builder builder) {
            if (this.current != null) {
                fileBuilder.addMessageType(this.current);
            }
            this.current = builder;
            this.msgFieldNumber = 1;
        }

        public Builder addField(FieldDescriptor.Type primType, String name) {
            return addField(FieldDescriptorProto.Label.LABEL_OPTIONAL, primType, name, null);
        }

        public Builder addRepeatedField(FieldDescriptor.Type primType, String name) {
            return addField(FieldDescriptorProto.Label.LABEL_REPEATED, primType, name, null);
        }

        public Builder addMapField(
                FieldDescriptor.Type keyType, FieldDescriptor.Type valueType,
                String name) {
            String mapName = "MAP_" + keyType.name() + "_" + valueType.name();

            if (!mapTypes.containsKey(mapName)) {
                DescriptorProto.Builder mapBuilder = DescriptorProto.newBuilder().setName(mapName);
                FieldDescriptorProto.Builder keyBuilder = FieldDescriptorProto.newBuilder()
                        .setLabel(FieldDescriptorProto.Label.LABEL_OPTIONAL)
                        .setType(keyType.toProto())
                        .setName("key").setNumber(1);
                FieldDescriptorProto.Builder valueBuilder = FieldDescriptorProto.newBuilder()
                        .setLabel(FieldDescriptorProto.Label.LABEL_OPTIONAL)
                        .setType(valueType.toProto())
                        .setName("value").setNumber(2);

                mapBuilder.addField(keyBuilder).addField(valueBuilder);
                mapBuilder.setOptions(MessageOptions.newBuilder().setMapEntry(true));
                fileBuilder.addMessageType(mapBuilder);
                mapTypes.put(mapName, mapBuilder);
            }

            FieldDescriptorProto.Builder fieldBuilder = FieldDescriptorProto.newBuilder();

            fieldBuilder.setLabel(FieldDescriptorProto.Label.LABEL_REPEATED).setName(name)
                    .setType(FieldDescriptor.Type.MESSAGE.toProto())
                    .setNumber(newFieldNumber()).setTypeName(mapName);
            addField(fieldBuilder);
            return this;
        }

        public Builder addField(FieldDescriptorProto.Builder fieldBuilder) {
            current.addField(fieldBuilder.build());
            return this;
        }

        private int newFieldNumber() {
            return msgFieldNumber++;
        }

        private Builder addField(FieldDescriptorProto.Label label, FieldDescriptor.Type primType,
                                 String name, String defaultVal) {
            FieldDescriptorProto.Builder fieldBuilder = FieldDescriptorProto.newBuilder();

            fieldBuilder.setLabel(label).setType(primType.toProto());
            fieldBuilder.setName(name).setNumber(newFieldNumber());

            if (defaultVal != null) {
                fieldBuilder.setDefaultValue(defaultVal);
            }
            addField(fieldBuilder);
            return this;
        }
    }
}
