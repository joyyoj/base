package yidian.common.proto;

import com.google.protobuf.Descriptors;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.DynamicMessage;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sunshangchun on 16/3/9.
 */
public class MessageWrapper {
    private final DynamicMessage msg;
    private final List<FieldDescriptor> fields;

    public MessageWrapper(DynamicMessage dynamicMessage) {
        this.msg = dynamicMessage;
        this.fields = dynamicMessage.getDescriptorForType().getFields();
    }

    public DynamicMessage get() {
        return msg;
    }

    public Object getField(int index) {
       return msg.getField(fields.get(index));
    }

    public Object getMap(int index) {
        Collection<Object> entrySet = (Collection<Object>) msg.getField(fields.get(index));
        Map map = new HashMap();

        for (Object object : entrySet) {
            DynamicMessage msg = (DynamicMessage) object;
            Object[] kv = new Object[2];

            for (Map.Entry<FieldDescriptor, Object> entry : msg.getAllFields().entrySet()) {
                if (entry.getKey().equals("key")) {
                    kv[0] = entry.getValue();
                } else {
                    kv[1] = entry.getValue();
                }
            }
            map.put(kv[0], kv[1]);
        }
        return map;
    }

    public static class Builder {
        private final Descriptors.Descriptor descriptor;
        private final List<FieldDescriptor> fields;
        private final DynamicMessage.Builder builder;

        public Builder(Descriptors.Descriptor descriptor) {
            this.descriptor = descriptor;
            this.fields = descriptor.getFields();
            builder = DynamicMessage.newBuilder(descriptor);
        }

        public Builder setField(int index, Object value) {
            builder.setField(getField(index), value);
            return this;
        }

        public Builder setField(String name, Object value) {
            FieldDescriptor fieldDescriptor = descriptor.findFieldByName(name);

            builder.setField(fieldDescriptor, value);
            return this;
        }

        public Builder setField(FieldDescriptor field, Object value) {
            builder.setField(field, value);
            return this;
        }

        public DynamicMessage.Builder get() {
            return builder;
        }

        public FieldDescriptor getField(int fieldIndex) {
            return fields.get(fieldIndex);
        }

        public FieldDescriptor getField(String name) {
            return descriptor.findFieldByName(name);
        }

        public Builder addRepeatedField(int fieldIndex, Object value) {
            builder.addRepeatedField(getField(fieldIndex), value);
            return this;
        }

        public Builder addRepeatedField(String fieldName, Object value) {
            builder.addRepeatedField(descriptor.findFieldByName(fieldName), value);
            return this;
        }

        public Builder putToMap(int index, Object key, Object value) {
            Descriptors.Descriptor entryDesc = getField(index).getMessageType();
            DynamicMessage.Builder entry = DynamicMessage.newBuilder(entryDesc);

            entry.setField(entryDesc.findFieldByName("key"), key);
            entry.setField(entryDesc.findFieldByName("value"), value);
            builder.addRepeatedField(getField(index), entry.build());

            return this;
        }

        public DynamicMessage build() {
            return builder.build();
        }
    }
}
