package yidian.common.test;

import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import yidian.common.io.FileUtils;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;


public class TestUtils {
    public static final String TEST_DIR = "testDir";
    private static TestUtils instance;

    private final String testDir;
    private boolean autoCreateDir = true;

    public static void initLog4j(String log4j) {
        LogManager.resetConfiguration();
        PropertyConfigurator.configure(log4j);
    }

    private static void initLog4j(InputStream log4j) {
        LogManager.resetConfiguration();
        Properties properties = new Properties();

        try {
            properties.load(log4j);
            PropertyConfigurator.configure(properties);
        } catch (IOException ie) {
            throw new IllegalStateException(ie);
        }
    }

    public TestUtils(String testDir) {
        this.testDir = testDir;
    }

    public TestUtils setUpEnv() {
        try {
            FileUtils.mkDirRecursively(new File(getTestDir() + "/expect"));
            FileUtils.mkDirRecursively(new File(getTestDir() + "/input"));
            FileUtils.mkDirRecursively(new File(getTestDir() + "/output"));
        } catch (Exception e) {
            throw new IllegalStateException("cannot init ", e);
        }
        initLog4j();
        return this;
    }

    public void setAutoCreateDir(boolean autoCreateDir) {
        this.autoCreateDir = autoCreateDir;
    }

    public static TestUtils getDefault() {
        if (instance == null) {
            instance = new TestUtils(initTestConf());
        }
        return instance;
    }

    public String getTestDir() {
        return testDir;
    }

    public static void initLog4j() {
        try {
            initLog4j(currentClassLoader().getResourceAsStream("log4j-test.properties"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // return className and methodName

    /**
     * should called by testcase directly
     * @return
     */
    public static String[] getTestCase() {
        StackTraceElement[] elements = new Exception().getStackTrace();
        int index = elements[1].getClassName().lastIndexOf(".");

        return new String[] {
                elements[1].getClassName().substring(index + 1),
                elements[1].getMethodName()
        };
    }

    private static String initTestConf() {
        String testDir = "";

        if (System.getProperties().containsKey(TEST_DIR)) {
            testDir = System.getProperty(TEST_DIR);
        } else {
            URL url = getResource("test.conf");

            if (url != null) {
                File file = new File(url.getFile());
                try {
                    final Properties props = new Properties();

                    props.load(new FileInputStream(file));
                    testDir = props.getProperty(TEST_DIR);
                } catch (IOException ie) {
                    ie.printStackTrace();
                    // ignore load exception
                }
            }
        }
        if (Strings.isNullOrEmpty(testDir)) {
            return new File("tests").getAbsolutePath();
        } else {
            return testDir;
        }
    }

    public static boolean createDirIfNotExists(String path) {
        File file = new File(path);

        if (file.exists()) {
            return file.isDirectory();
        } else {
            return file.mkdirs();
        }
    }

    public int diff(String... path) {
        return diff(new File(output(path)), new File(expect(path)));
    }

    public static String flatDir(String... dirs) {
        return Joiner.on("_").join(dirs);
    }

    public String expect(String... dirs) {
        return getTestDir() + "/expect/" + Joiner.on("/").join(dirs);
    }

    public String input(String... dirs) {
        return getTestDir() + "/input/" + Joiner.on("/").join(dirs);
    }

    public String output(String... dirs) {
        return getTestDir() + "/output/" + Joiner.on("/").join(dirs);
    }

    public String resource(String... path) throws IOException {
        return getTestDir() + "/resource/" + Joiner.on("/").join(path);
    }

    public static URL getResource(String name) {
        return Thread.currentThread().getContextClassLoader().getResource(name);
    }

    public static ClassLoader currentClassLoader() {
        return Thread.currentThread().getContextClassLoader();
    }

    private static String extractAsFile(InputStream inputStream) {
        try {
            String diffShell = File.createTempFile("diff", ".sh").getPath();

            FileUtils.writeToFile(inputStream, new File(diffShell));
            return diffShell;
        } catch (Exception e) {
            throw new IllegalStateException("can not create diff.sh", e);
        }
    }

    /**
     * diff files, ignore order
     *
     * @return diff line count
     */
    public static int diff(File expected, File actual) {
        String diffShell = extractAsFile(currentClassLoader().getResourceAsStream("diff.sh"));
        String cmd = "bash " + diffShell + " "
                + expected.getAbsolutePath()
                + " " + actual.getAbsolutePath();
        try {
            System.err.println("exec diff command " + cmd);
            int ret = Runtime.getRuntime().exec(cmd).waitFor();
            return ret;
        } catch (Exception ie) {
            System.err.println(ie.getMessage());
            return 1;
        }
    }

    public static List<String> listFiles(final String absLocation, final String filter) {
        String[] files = new File(absLocation).list(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.matches(filter);
            }
        });

        if (files == null) {
            return new ArrayList<String>();
        }
        return Arrays.asList(files);
    }
}

