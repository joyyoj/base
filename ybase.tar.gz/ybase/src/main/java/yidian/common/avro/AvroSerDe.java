package yidian.common.avro;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.*;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecord;
import org.apache.avro.specific.SpecificRecordBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AvroSerDe {
    private static final Logger logger = LoggerFactory.getLogger(AvroSerDe.class);

    /**
     * Serializes the specified Avro record into a byte array
     *
     * @param record the Avrop record
     * @return byte array containing serialized form of the specified Avro record
     */
    public static byte[] serialize(GenericRecord record) throws IOException {
        byte[] serializedValue;
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            Encoder encoder = EncoderFactory.get().binaryEncoder(bos, null);
            GenericDatumWriter<GenericRecord> writer = new GenericDatumWriter<>(record.getSchema());

            writer.write(record, encoder);
            encoder.flush();
            serializedValue = bos.toByteArray();
            return serializedValue;
        }
    }

    public static GenericRecord deserialize(byte[] buf, Schema schema) throws IOException {
        DatumReader<GenericRecord> reader = new GenericDatumReader<>(schema);
        Decoder decoder = DecoderFactory.get().binaryDecoder(buf, null);
        GenericRecord result = reader.read(null, decoder);

        return result;
    }

    public static byte[] serialize(SpecificRecordBase record) throws IOException {
        byte[] serializedValue;
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            Encoder encoder = EncoderFactory.get().binaryEncoder(bos, null);
            SpecificDatumWriter writer = new SpecificDatumWriter<>(record.getSchema());

            writer.write(record, encoder);
            encoder.flush();
            serializedValue = bos.toByteArray();
            return serializedValue;
        }
    }

    public static <T extends SpecificRecord> T deserialize(byte[] buf, Class<T> cls)
            throws IOException {
        SpecificDatumReader<T> reader = new SpecificDatumReader<>(cls);
        Decoder decoder = DecoderFactory.get().binaryDecoder(buf, null);
        return reader.read(null, decoder);
    }
}

