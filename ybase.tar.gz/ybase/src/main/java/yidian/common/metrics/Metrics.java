package yidian.common.metrics;

import com.google.common.collect.Maps;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.AsyncHttpClientConfig;
import com.ning.http.client.providers.jdk.JDKAsyncHttpProvider;
import com.typesafe.config.Config;
import com.yidian.serving.metrics.MetricsFactory;
import com.yidian.serving.metrics.MetricsFactoryUtil;
import com.yidian.serving.metrics.OnDemandMetricsFactory;
import com.yidian.serving.metrics.core.Histogram;
import com.yidian.serving.metrics.core.Meter;
import com.yidian.serving.metrics.reporter.opentsdb.HttpOpenTsdbClient;
import com.yidian.serving.metrics.reporter.opentsdb.OpenTsdbClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import yidian.common.base.YConfig;

import java.net.InetAddress;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * Metrics send metric to tsdb.
 */
public class Metrics {
    static Logger logger = LoggerFactory.getLogger(Metrics.class);
    static AtomicBoolean isIntialized = new AtomicBoolean(false);
    static String qualifier;
    static MetricsFactory factory;
    static Set<String> consumers = new HashSet<>();

    public static void startUp(YConfig yconf, Consumer<MetricsFactory> postHook) {
        String caller = new Exception().getStackTrace()[1].getClassName();
        startUp(yconf, postHook, caller);
    }

    public synchronized static void startUp(
            YConfig yconf, Consumer<MetricsFactory> postHook, String consumerId) {
        if (isIntialized.compareAndSet(false, true)) {
            try {
                Config config = yconf.get();
                Config servingMetricsConfig = config.getConfig("serving-metrics");
                String openTsdbAddr = servingMetricsConfig.getString("opentsdb.address");

                logger.info("opentsdb.address:" + openTsdbAddr);
                Map<String, String> tags = Maps.newHashMap();
                String hostName = InetAddress.getLocalHost().getHostName();
                qualifier = servingMetricsConfig.getString("prefix");
                if (servingMetricsConfig.hasPath("prefix")) {
                } else {
                    qualifier = servingMetricsConfig.getString("name");
                }
                tags.put("component", qualifier);
                tags.put("host", hostName);
                tags.put("env", servingMetricsConfig.getString("env"));

                AsyncHttpClient asyncHttpClient = new AsyncHttpClient(new JDKAsyncHttpProvider(
                        new AsyncHttpClientConfig.Builder().build()));
                OpenTsdbClient openTsdbClient = new HttpOpenTsdbClient(asyncHttpClient, openTsdbAddr);

                factory = new OnDemandMetricsFactory(tags, openTsdbClient);
                MetricsFactoryUtil.register(factory);

                logger.info("success to starting all, tsdb:" + openTsdbAddr);
            } catch (Exception e) {
                logger.info("serving-metrics config is not found, will not send serving metrics", e);
                throw new IllegalStateException(e);
            }
        }
        if (!consumers.contains(consumerId)) {
            consumers.add(consumerId);
            postHook.accept(factory);
        }
    }

    public static Meter meter(String source) {
        return factory.getMeter(qualifier + "." + source);
    }

    public static Histogram histogram(String source) {
        return factory.getHistogram(qualifier + "." + source);
    }
}
