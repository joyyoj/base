package yidian.common.http;

@Deprecated
public class Uris extends yidian.common.net.Uris {
}
