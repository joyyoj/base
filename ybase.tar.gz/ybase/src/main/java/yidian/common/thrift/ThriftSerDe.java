package yidian.common.thrift;

import org.apache.thrift.TBase;
import org.apache.thrift.TDeserializer;
import org.apache.thrift.TException;
import org.apache.thrift.TSerializer;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.protocol.TProtocolFactory;
import org.apache.thrift.transport.TMemoryInputTransport;
import yidian.common.base.ByteArray;

import java.io.IOException;
import java.nio.ByteBuffer;


/**
 * SerDe in thrift object.
 */
public class ThriftSerDe {
    protected TProtocolFactory tProtocolFactory;
    protected ThriftDeserializer deserializer;
    protected TSerializer serializer;

    public enum Type {
        BINARY,
        COMPACT;
    }

    // thrift serde is not thread safe, so we use thread local make it thread safe
    private static ThreadLocal<ThriftSerDe> instance = new ThreadLocal<ThriftSerDe>() {
        @Override
        protected ThriftSerDe initialValue() {
            return new ThriftSerDe();
        }
    };
    private static ThreadLocal<ThriftSerDe> binaryInstance = new ThreadLocal<ThriftSerDe>() {
        @Override
        protected ThriftSerDe initialValue() {
            return new ThriftSerDe(new TBinaryProtocol.Factory());
        }
    };

    public static class ThriftDeserializer extends TDeserializer {
        // use protocol and transport directly instead of using ones in TDeserializer
        private final TMemoryInputTransport trans = new TMemoryInputTransport();
        private TProtocol protocol;

        public ThriftDeserializer(TProtocolFactory protocolFactory) {
            super(protocolFactory);
            protocol = protocolFactory.getProtocol(trans);
        }

        @Override
        public void deserialize(TBase base, byte[] bytes) throws TException {
            deserialize(base, bytes, 0, bytes.length);
        }

        /**
         * Same as {@link #deserialize(TBase, byte[])}, but much more buffer copy friendly.
         */
        public void deserialize(TBase base, byte[] bytes, int offset, int len) throws TException {
            protocol.reset();
            trans.reset(bytes, offset, len);
            base.read(protocol);
        }
    }

    public static ThriftSerDe get(Type type) {
        if (type == Type.BINARY) {
            return getBinary();
        } else {
            return get();
        }
    }

    public static ThriftSerDe getBinary() {
        return binaryInstance.get();
    }

    public static ThriftSerDe get() {
        return instance.get();
    }

    public ThriftSerDe() {
        this(new TCompactProtocol.Factory());
    }

    public ThriftSerDe(TProtocolFactory protocolFactory) {
        this.tProtocolFactory = protocolFactory;
        deserializer = new ThriftDeserializer(tProtocolFactory);
        serializer = new TSerializer(tProtocolFactory);
    }

    public byte[] serialize(TBase data) throws IOException {
        try {
            byte[] result = serializer.serialize(data);
            return result;
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    public <T extends TBase> T deserialize(ByteArray data, Class<T> cls) throws IOException {
       return deserialize(data.array(), data.offset(), data.size(), cls);
    }

    public <T extends TBase> T deserialize(ByteBuffer data, Class<T> cls)
            throws IOException {
        return deserialize(data.array(), data.arrayOffset() + data.position(),
                data.remaining(), cls);
    }

    public <T extends TBase> T deserialize(byte[] data, Class<T> cls) throws IOException {
        return deserialize(data, 0, data.length, cls);
    }

    public <T extends TBase> T deserialize(byte[] data, int offset, int len, Class<T> cls) throws IOException {
        try {
            TBase object = cls.newInstance();
            deserializer.deserialize(object, data, offset, len);
            return (T) object;
        } catch (Exception e) {
            throw new IOException(e);
        }
    }
}

