package yidian.common.thrift;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import org.apache.thrift.TProcessor;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocolFactory;
import org.apache.thrift.server.*;
import org.apache.thrift.transport.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import yidian.common.base.YConfig;
import yidian.common.base.YConfig.Vars;

import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by tianchao on 14-10-23.
 */
public class ThriftService {
    public static Logger log = LoggerFactory.getLogger(ThriftService.class);
    public static final Vars THRIFT_PORT = Vars.of("yidian.data.thrift.port", 9090);
    public static final Vars THRIFT_SERVER_TYPE = Vars.of("yidian.data.thrift.server", "nonblocking");
    public static final Vars THRIFT_SERVER_FRAMED = Vars.of("yidian.data.thrift.framed", false);
    private static final Vars THRIFT_SERVER_THREAD_NUMBER = Vars.of("yidian.data.thrift.server.threadnum", 10);
    public static final Vars THRIFT_SERVER_COMPACT = Vars.of("yidian.data.thrift.compact", false);

    private YConfig config;
    TServer server;
//    MetricRegistry metrics;

    private static TProtocolFactory getTProtocolFactory(boolean isCompact) {
        if (isCompact) {
            log.info("Using compact protocol");
            return new TCompactProtocol.Factory();
        } else {
            log.info("Using binary protocol");
            return new TBinaryProtocol.Factory();
        }
    }

    private static TTransportFactory getTTransportFactory(boolean framed) {
        if (framed) {
            log.info("Using framed transport");
            return new TFramedTransport.Factory();
        } else {
            return new TTransportFactory();
        }
    }

    private static TThreadedSelectorServer getTThreadedSelectorServer(TProtocolFactory protocolFactory, TProcessor processor,
                                                 TTransportFactory transportFactory
            , InetSocketAddress inetSocketAddress,int threadNum) throws TTransportException {
        TNonblockingServerTransport serverTransport = new TNonblockingServerSocket(inetSocketAddress);

        TThreadedSelectorServer.Args serverArgs = new TThreadedSelectorServer.Args(serverTransport);
        ExecutorService executorService = createExecutor(threadNum);
        log.info("starting TThreadedSelectorServer Thrift server on " + inetSocketAddress.toString()
                +" "+threadNum+" threads");
        serverArgs.executorService(executorService);
        serverArgs.processor(processor);
        serverArgs.transportFactory(transportFactory);
        serverArgs.protocolFactory(protocolFactory);
        return new TThreadedSelectorServer(serverArgs);
    }

    private static TServer getTNonBlockingServer(TProtocolFactory protocolFactory, TProcessor processor,
                                                 TTransportFactory transportFactory, InetSocketAddress inetSocketAddress) throws TTransportException {
        TNonblockingServerTransport serverTransport = new TNonblockingServerSocket(inetSocketAddress);
        log.info("starting Nonblocking Thrift server on " + inetSocketAddress.toString());
        TNonblockingServer.Args serverArgs = new TNonblockingServer.Args(serverTransport);
        serverArgs.processor(processor);
        serverArgs.transportFactory(transportFactory);
        serverArgs.protocolFactory(protocolFactory);
        return new TNonblockingServer(serverArgs);
    }

    private static TServer getTHsHaServer(TProtocolFactory protocolFactory,
                                          TProcessor processor, TTransportFactory transportFactory,
                                          InetSocketAddress inetSocketAddress,int threadNum)
            throws TTransportException {
        TNonblockingServerTransport serverTransport = new TNonblockingServerSocket(inetSocketAddress);
        log.info("starting HsHA Thrift server on " + inetSocketAddress.toString());
        THsHaServer.Args serverArgs = new THsHaServer.Args(serverTransport);
        ExecutorService executorService = createExecutor(threadNum);
        serverArgs.executorService(executorService);
        serverArgs.processor(processor);
        serverArgs.transportFactory(transportFactory);
        serverArgs.protocolFactory(protocolFactory);
        return new THsHaServer(serverArgs);
    }

    private static TServer getTThreadPoolServer(TProtocolFactory protocolFactory, TProcessor processor,
            TTransportFactory transportFactory, InetSocketAddress inetSocketAddress,int threadNum) throws TTransportException {
        TServerTransport serverTransport = new TServerSocket(inetSocketAddress);
        log.info("starting ThreadPool Thrift server on " + inetSocketAddress.toString());
        TThreadPoolServer.Args serverArgs = new TThreadPoolServer.Args(serverTransport);
        serverArgs.processor(processor);
        ExecutorService executorService = createExecutor(
                threadNum);
        serverArgs.executorService(executorService);
        serverArgs.transportFactory(transportFactory);
        serverArgs.protocolFactory(protocolFactory);
        return new TThreadPoolServer(serverArgs);
    }

    private static ExecutorService createExecutor( int workerThreads) {
        LinkedBlockingQueue callQueue = new LinkedBlockingQueue();
        ThreadFactoryBuilder tfb = new ThreadFactoryBuilder();
        tfb.setDaemon(true);
        tfb.setNameFormat("thrift-worker-%d");
        return new ThreadPoolExecutor(workerThreads, workerThreads*4,
                Long.MAX_VALUE, TimeUnit.SECONDS, callQueue, tfb.build());
    }

    public TServer initServer(final TProcessor processor) throws TTransportException {
        int port = config.getInt(THRIFT_PORT);
        String serverType = config.get(THRIFT_SERVER_TYPE);
        System.out.println("serverType:"+serverType);
        serverType = serverType.toLowerCase();
        boolean nonblocking = false;
        boolean hsha = false;
        boolean threadpool = false;
        boolean selected = false;
        if(serverType.equals("nonblocking")){
            nonblocking = true;
        } else if(serverType.equals("hsha")){
            hsha = true;
        } else if(serverType.equals("threadpool")){
            threadpool = true;
        } else if (serverType.equals("selected")){
            selected = true;
        } else { // default as nonblocking
            hsha = true;
        }
        int threadNum = config.getInt(THRIFT_SERVER_THREAD_NUMBER);
        boolean compact = config.getBoolean(THRIFT_SERVER_COMPACT);
        TProtocolFactory protocolFactory = getTProtocolFactory(compact);
        boolean framed = config.getBoolean(THRIFT_SERVER_FRAMED) || nonblocking || hsha || selected;
        TTransportFactory transportFactory = getTTransportFactory(framed);
        InetSocketAddress inetSocketAddress = new InetSocketAddress(port);
        if (nonblocking) {
            server = getTNonBlockingServer(protocolFactory, processor, transportFactory, inetSocketAddress);
        } else if (hsha) {
            server = getTHsHaServer(protocolFactory, processor, transportFactory, inetSocketAddress,threadNum);
        } else if(selected){
            server = getTThreadedSelectorServer(protocolFactory, processor, transportFactory, inetSocketAddress,threadNum);
        } else {
            server = getTThreadPoolServer(protocolFactory, processor, transportFactory, inetSocketAddress,threadNum);
        }
        return server;
    }

    /**
     * Start a service with specified processor
     * @param processor
     */
    public void start(final TProcessor processor){
        try {
            server = initServer(processor);
            log.info("Starting the server "+server.getClass()+" ...");
            server.serve();
            log.info("Successfully stared thrift service");
        } catch (Exception e){
            e.printStackTrace();
            log.error("Failed to start thrift service",e);
        }
    }

    public void setConf(YConfig conf) {
        this.config = conf;
    }

    public YConfig getConf() {
        return config;
    }

//    @Override
//    public void setupMetricRegistry(MetricRegistry registry) {
//        if(registry==null) {
//            registry = new MetricRegistry();
//        }
//        metrics = registry;
//
//        String[] reporters = config.getStrings("yidian.data.thrift.monitor.reporter");
//        if(reporters==null || reporters.length == 0){
//            reporters = new String[1];
//            reporters[0] = "console";
//        }
//        for(String r : reporters){
//            r = r.toLowerCase();
//            int reportInterval = config.getInt("yidian.data.thrift.monitor.report.interval",30);
//            if(r.equals("console")){
//                ConsoleReporter reporter = ConsoleReporter.forRegistry(metrics)
//                    .convertRatesTo(TimeUnit.SECONDS)
//                    .convertDurationsTo(TimeUnit.MILLISECONDS)
//                    .build();
//                reporter.start(reportInterval, TimeUnit.SECONDS);
//                log.info("started console reporter");
//            } else if(r.equals("tsdb")){
//                String tsdbEndpoint = config.get("yidian.data.thrift.monitor.tsdb","http://test1-2.kafka.yidian.com:14242/");
//
//                String host = config.get("yidian.data.thrift.monitor.tsdb.host","test");
//                OpenTsdbReporter.forRegistry(metrics)
//                        .prefixedWith("neo.profile")
//                        .withTags(ImmutableMap.of("host",host)).withBatchSize(50)
//                        .build(OpenTsdb.forService(tsdbEndpoint)
//                                .withConnectTimeout(5000)
//                                .withReadTimeout(5000)
//                                .create())
//                        .start(reportInterval, TimeUnit.SECONDS);
//                log.info("started TSDB reporter to endpoint "+tsdbEndpoint);
//            } else if(r.equals("jmx")){
//                final JmxReporter reporter = JmxReporter.forRegistry(registry).build();
//                reporter.start();
//            }
//        }
//
//    }
}
