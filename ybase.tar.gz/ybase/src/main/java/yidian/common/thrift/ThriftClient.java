package yidian.common.thrift;

import com.google.common.net.HostAndPort;
import lombok.Data;
import lombok.experimental.Accessors;
import org.apache.thrift.TServiceClient;
import org.apache.thrift.TServiceClientFactory;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;

import java.io.Closeable;

/**
 * Not thread safely.
 * retryable thrift client.
 */
public class ThriftClient<T extends TServiceClient> implements Closeable {
    protected final Args thriftArgs;
    private T client;
    private TServiceClientFactory<T> clientFactory;
    private TTransport transport;
    private boolean isConnectionBroken = false;

    public ThriftClient(Args thriftArgs, TServiceClientFactory<T> factory) {
        this.thriftArgs = thriftArgs;
        this.clientFactory = factory;
    }

    public T getHandler() throws TTransportException {
        if (client == null || isConnectionBroken) {
            client = createNewConnection();
            isConnectionBroken = false;
        }
        return client;
    }

    private void disconnect() {
        if (transport != null) {
            transport.close();
            transport = null;
        }
    }

    protected T createNewConnection() throws TTransportException {
        disconnect();
        transport = thriftArgs.createTransport();
        transport.open();
        TProtocol protocol = thriftArgs.createProtocol(transport);
        return clientFactory.getClient(protocol);
    }

    // 如果连接失败,手工标记位broken
    public void markAsBrokenConnection() {
        this.isConnectionBroken = true;
    }

    @Override
    public void close() {
        disconnect();
    }

    @Override
    public String toString() {
        return thriftArgs.getHostPort().toString();
    }

    @Accessors(chain = true)
    @Data(staticConstructor = "of")
    public static class Args extends yidian.common.base.Args {
        final String hostPort;
        int timeout = 1000;
        boolean isCompacted = false;
        boolean isFramed = false;
        int maxRetries = 1;

        public TTransport createTransport() {
            HostAndPort hostAndPort = HostAndPort.fromString(hostPort);
            TTransport transport = new TSocket(hostAndPort.getHostText(),
                    hostAndPort.getPort(), timeout);
            return isFramed ? new TFramedTransport(transport) : transport;
        }

        public TProtocol createProtocol(TTransport transport) {
            return isCompacted ? new TCompactProtocol(transport)
                    : new TBinaryProtocol(transport);
        }
    }
}
