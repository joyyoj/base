package yidian.common.net;

import com.google.common.base.Preconditions;
import com.google.common.base.Splitter;
import com.google.common.net.HostAndPort;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.net.URI;
import java.util.*;

/**
 * helper for Uri.
 */
public class Uris {
    public static Map<String, String> getParams(URI uri) {
        return getParams(uri.getQuery());
    }

    public static Map<String, String> getParams(String query) {
        Map<String, String> result = new LinkedHashMap<>();

        if (query != null) {
            Iterable<String> kvs = Splitter.on("&").split(query);

            for (String kv : kvs) {
                String[] entry = kv.split("=", 2);

                if (entry.length == 2) {
                    result.put(entry[0], entry[1]);
                }
            }
        }
        return result;
    }

    public static Config parseParams(URI uri) {
        Map<String, String> map = getParams(uri);
        Properties props = new Properties();
        props.putAll(map);

        return ConfigFactory.parseProperties(props);
    }

    public static List<String> getUriPath(String path) {
        Iterable<String> it =  Splitter.on("/").omitEmptyStrings().split(path);
        List<String> parts = new ArrayList<>();

        for (String p : it) {
            parts.add(p);
        }
        return parts;
    }

    public static String joinAddress(String[] hosts, int port) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < hosts.length; ++i) {
            String host = hosts[i];

            sb.append(host + ":" + port);
            if (i != hosts.length - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }


    public static Map.Entry<List<String>, Integer> splitAddress(String zkAddr) {
        List<String> hosts = new ArrayList<>();
        int port = 0;

        for (String str : Splitter.on(",").omitEmptyStrings().trimResults().split(zkAddr)) {
            String[] hostPort = str.split(":", 2);

            hosts.add(hostPort[0]);
            if (hostPort.length == 2) {
                int curPort = Integer.parseInt(hostPort[1]);

                if (port != 0 && port != curPort) {
                    throw new IllegalArgumentException("port is not equal");
                }
                port = curPort;
            }
        }
        return new AbstractMap.SimpleImmutableEntry<>(hosts, port);
    }

    // scheme://host:port/dbName/tableName/partitionName?query
    public static TablePath convertToTablePath(String uri) {
        uri = uri.trim();
        int index = uri.indexOf(":");
        TablePath tablePath = new TablePath();

        Preconditions.checkState(index != -1);
        tablePath.scheme = uri.substring(0, index);
        int pindex = uri.indexOf("/", index + 3); // ignore ://
        String auth = uri.substring(index + 3, pindex);
        HostAndPort hostPort = HostAndPort.fromString(auth);
        tablePath.host = hostPort.getHostText();
        tablePath.port = hostPort.getPortOrDefault(-1);

        String path;
        int qindex = uri.indexOf("?", pindex);
        if (qindex != -1) {
            String query = uri.substring(qindex + 1);
            tablePath.query.putAll(getParams(query));

            path = uri.substring(pindex + 1, qindex);
        } else {
            path = uri.substring(pindex + 1);
        }
        tablePath.rawPath = path;
        fillPath(tablePath, path);
        return tablePath;
    }

    static void fillPath(TablePath tablePath, String path) {
        int partIndex = path.indexOf('=');
        int startIdx;

        if (partIndex != -1) { // exists path name
            startIdx = path.lastIndexOf("/", partIndex);

            String pNames = path.substring(startIdx + 1);
            // x=x/x=x
            for (String pname : Splitter.on("/").split(pNames)) {
                String[] kv = pname.split("=", 2);
                if (kv.length == 2) {
                    tablePath.partitionName.put(kv[0], kv[1]);
                }
            }
        } else {
            startIdx = path.length();
        }
        if (startIdx > 0) {
            String name = path.substring(0, startIdx);
            int index = name.lastIndexOf("/");
            tablePath.dbName = name.substring(0, index);
            tablePath.tableName = name.substring(index + 1);
        }
    }

    public static class TablePath {
        public String scheme = "";
        public String host = "";
        public int port;
        public String dbName = "";
        public String tableName = "";
        public String rawPath = "";
        public final Map<String, String> partitionName = new LinkedHashMap<>();
        public final Map<String, String> query = new LinkedHashMap<>();

        public String getScheme() {
            return scheme;
        }

        public String getHost() {
            return host;
        }

        public int getPort() {
            return port;
        }

        public String getDb() {
            return dbName;
        }

        public String getTable() {
            return tableName;
        }

        public String getRawPath() {
            return rawPath;
        }

        public Map<String, String> getPartition() {
            return partitionName;
        }

        public Map<String, String> getQuery() {
            return query;
        }
    }
}
