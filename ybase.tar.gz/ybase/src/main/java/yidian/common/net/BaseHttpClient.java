package yidian.common.net;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sunshangchun on 15/12/2.
 */
public class BaseHttpClient {
    private static final String USER_AGENT = "Mozilla/5.0";  // test
    private static final int TOTAL_CONNECTION = 20;
    public final Logger logger = LoggerFactory.getLogger(this.getClass());
    private String url;
    private String cookies;
    private Map<String, String> header;
    private final HttpClientConnectionManager connectionManager;
    private final RequestConfig requestConfig;

    protected BaseHttpClient(HttpClientConnectionManager cm, String url, RequestConfig requestConfig) {
        this.url = url;
        this.connectionManager = cm;
        this.requestConfig = requestConfig;
        header = new HashMap<>();
    }

    public static BaseHttpClient create(HttpClientConnectionManager cm, String url, RequestConfig requestConfig) {
        return new BaseHttpClient(cm, url, requestConfig);
    }

    public static BaseHttpClient create(String baseUrl, int socketTimeout, int connectTimeout) {
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(socketTimeout)
                .setConnectTimeout(connectTimeout).build();
        return create(baseUrl, requestConfig, TOTAL_CONNECTION);
    }

    public static BaseHttpClient create(String baseUrl, int socketTimeout, int connectTimeout, int totalConnection) {
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(socketTimeout)
                .setConnectTimeout(connectTimeout).build();

        return create(baseUrl, requestConfig, totalConnection);
    }

    public static BaseHttpClient create(String baseUrl, RequestConfig requestConfig, int totalConnection) {
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(totalConnection);
        connManager.setDefaultMaxPerRoute(totalConnection);
        return new BaseHttpClient(connManager, baseUrl, requestConfig);
    }

    private CloseableHttpClient getClient() {
        return HttpClients.custom().setDefaultRequestConfig(requestConfig)
                .setConnectionManager(connectionManager)
                .build();
    }

    /**
     * send http request.
     */
    public CloseableHttpResponse get(String endPoint, Params param)
            throws IOException {
        HttpGet request = new HttpGet();
        List<NameValuePair> params = param.build();

        request.setHeader("User-Agent", USER_AGENT);
        request.setHeader("Accept",
                "text/json,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        request.setHeader("Accept-Language", "en-US,en;q=0.5");
        request.setHeader("cookies", getCookies());
        header.forEach((key, value) -> {
            request.setHeader(key, value);
        });

        try {
            URI uri = new URIBuilder(getUri(endPoint)).setParameters(params).build();

            request.setURI(uri);
        } catch (URISyntaxException e) {
            throw new IOException(e);
        }
        return getClient().execute(request);
    }

    protected String getUri(String endPoint) {
        return url + endPoint;
    }

    /**
     * send http post.
     */
    public CloseableHttpResponse post(String endPoint, Params param)
            throws IOException {
        List<NameValuePair> params = param.build();
        HttpPost post = new HttpPost(getUri(endPoint));

        // add header
//    post.setHeader("Host", "accounts.google.com");
        post.setHeader("User-Agent", USER_AGENT);
        post.setHeader("Accept",
                "text/json,application/json;q=0.9,*/*;q=0.8");
        post.setHeader("Accept-Language", "en-US,en;q=0.5");
        String cookies = getCookies();
        header.forEach((key, value) -> {
            post.setHeader(key, value);
        });

        if (cookies != null) {
            post.setHeader("cookies", cookies);
        }
        post.setHeader("Connection", "keep-alive");
        post.setEntity(new UrlEncodedFormEntity(params));

        return getClient().execute(post);
    }

    /**
     * send http post.
     */
    public CloseableHttpResponse post(String endPoint, HttpEntity entity)
            throws IOException {
        HttpPost post = new HttpPost(getUri(endPoint));
        String cookies = getCookies();

        if (cookies != null) {
            post.setHeader("cookies", cookies);
        }
        post.setHeader("Connection", "keep-alive");
        post.setEntity(entity);

        return getClient().execute(post);
    }

    public String getCookies() {
        return cookies;
    }

    public void setCookies(String cookies) {
        this.cookies = cookies;
    }

    public void setHeader(Map<String, String> header) {
        this.header = header;
    }

    public JsonObject getAsJsonObject(HttpResponse response)
            throws IOException {
        try {
            BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));

            return new JsonParser().parse(rd).getAsJsonObject();
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            if(response != null) {
                EntityUtils.consume(response.getEntity());
            }
        }
    }

    public List<String> getAsString(HttpResponse response) throws IOException {
        try {
            BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));
            List<String> result = new ArrayList<>();
            String line = "";

            while ((line = rd.readLine()) != null) {
                result.add(line);
            }
            return result;
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            if(response != null) {
                EntityUtils.consume(response.getEntity());
            }
        }
    }

    public <T> T getAsObject(HttpResponse response, Class<T> cls)
            throws IOException {
        try {
            BufferedReader rd = new BufferedReader(
                    new InputStreamReader(response.getEntity().getContent()));
            return new Gson().fromJson(rd, cls);
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            if(response != null) {
                EntityUtils.consume(response.getEntity());
            }
        }
    }

    public static class Params {
        private final List<NameValuePair> pairs = new ArrayList<>();

        public Params create() {
            return new Params();
        }

        public Params add(String name, String value) {
            pairs.add(new BasicNameValuePair(name, value));
            return this;
        }

        public List<NameValuePair> build() {
            return pairs;
        }
    }
}
