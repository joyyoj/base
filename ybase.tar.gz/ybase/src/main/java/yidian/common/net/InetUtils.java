package yidian.common.net;

import com.google.common.base.Optional;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

/**
 * Created by sunshangchun on 16/1/28.
 */
public class InetUtils {
    public static Optional<InetAddress> getLocalHost() throws SocketException {
        Enumeration<NetworkInterface> networkInterfaces = NetworkInterface
                .getNetworkInterfaces();

        while (networkInterfaces.hasMoreElements()) {
            NetworkInterface ni = networkInterfaces.nextElement();
            Enumeration<InetAddress> nias = ni.getInetAddresses();

            while (nias.hasMoreElements()) {
                InetAddress ia = nias.nextElement();
                if (!ia.isLinkLocalAddress() && !ia.isLoopbackAddress()
                        && ia instanceof Inet4Address) {
                    return Optional.of(ia);
                }
            }
        }
        return Optional.absent();
    }
}
