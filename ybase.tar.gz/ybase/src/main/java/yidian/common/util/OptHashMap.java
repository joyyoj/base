package yidian.common.util;

import java.util.HashMap;
import java.util.function.BiFunction;


// use java8 instead.
@Deprecated
public class OptHashMap<K, V> extends HashMap<K, V> {
    public V getOrElse(Object key, V defaultV) {
        V value = super.get(key);

        return value == null ? defaultV : value;
    }

    public V put(K key, V value, BiFunction<V, V, V> merger) {
        V oldValue = super.get(key);
        V v = merger.apply(oldValue, value);
        super.put(key, v);
        return oldValue;
    }
}