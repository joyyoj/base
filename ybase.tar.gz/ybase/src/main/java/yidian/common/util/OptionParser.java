package yidian.common.util;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import com.typesafe.config.ConfigParseOptions;
import com.typesafe.config.ConfigSyntax;
import yidian.common.base.YConfig;

import java.util.Arrays;

/**
 * Created by sunshangchun on 16/6/29.
 */
public class OptionParser {
    public static final String CONF_KEY = "conf";
    String confName = "";
    Config options = ConfigFactory.empty();
    Config conf;

    public OptionParser setConf(YConfig conf) {
       this.conf = conf.get();
        return this;
    }

    public String[] parse(String[] args) {
        int i = 0;
        for (; i < args.length; ++i) {
            String arg = args[i];

            if (arg.startsWith("--")) {
                String cmd = arg.substring(2);
                Config c = ConfigFactory.parseString(cmd,
                        ConfigParseOptions.defaults().setSyntax(ConfigSyntax.PROPERTIES));

                if (c.hasPath(CONF_KEY)) {
                    confName = c.getString(CONF_KEY);
                }
                options = c.withFallback(options);
            } else {
                break;
            }
        }
        return Arrays.copyOfRange(args, i, args.length);
    }

    public YConfig getOptions() {
        return YConfig.create(options);
    }

    public YConfig getConf() {
        return getConf(false);
    }

    public YConfig getConf(boolean withDefault) {
        Config config;

        if (!confName.equals("")) {
            config = options.withFallback(YConfig.loadFile(confName).get());
        } else {
            config = options;
        }
        if (withDefault) {
            config = config.withFallback(ConfigFactory.load());
        }
        return YConfig.create(config);
    }
}
