package yidian.common.util;

import com.google.common.base.Function;
import com.google.common.base.Suppliers;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.function.Supplier;

public class PluginLoader<T> {
    private static final String CONNECTION_IMPL = "plugins.impl.";
    private static final String DEPRECATE_PLUGIN_DIR = "META-INF.plugins/";
    private static final String PLUGIN_DIR = "META-INF/plugins/";
    private final Map<String, Supplier<T>> suppliers = new HashMap<>();
    private final Map<String, String> typeMap = new HashMap<>();

    private static final Function<String, Object> DEFAULT_CREATOR = (className) -> {
        try {
            Class clazz = Class.forName(className);
            Constructor e = clazz.getDeclaredConstructor(
                    new Class[]{});

            e.setAccessible(true);
            return e.newInstance(new Object[0]);
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    };

    public static <T> PluginLoader<T> load(Class<T> t) {
        return find(t).load();
    }

    public static <T> PluginLoader<T> load(Class<T> t, Function<String, T> creator) {
        return find(t).setCreator(creator).load();
    }

    public Set<String> keySet() {
        return typeMap.keySet();
    }

    public T get(String name, Function<String, T> creator) {
        String value = typeMap.get(name);

        return creator.apply(value);
    }

    public T get(String name) {
        T value = suppliers.getOrDefault(name, () -> null).get();

        return value;
    }

    public static class Builder<T> {
        private boolean memoize = false;
        private final Class<T> cls;
        private Function<String, T> creator = (className) -> (T) DEFAULT_CREATOR.apply(className);
        private Map<String, Supplier<T>> registeSuppliers = new HashMap<>();

        private Builder(Class<T> t) {
            this.cls = t;
        }

        public Builder<T> register(String key, Supplier<T> value) {
            registeSuppliers.put(key, value);
            return this;
        }

        public Builder<T> setCreator(Function<String, T> creator) {
            this.creator = creator;
            return this;
        }

        public Builder<T> memoize(boolean memoized) {
            this.memoize = memoized;
            return this;
        }

        public PluginLoader<T> load() {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            InputStream is = classLoader.getResourceAsStream(PLUGIN_DIR + cls.getName());

            if (is == null) {
                is = classLoader.getResourceAsStream(DEPRECATE_PLUGIN_DIR + cls.getName());
            }
            PluginLoader<T> loader = new PluginLoader<>();

            if (is != null) {
                try {
                    Properties properties = new Properties();

                    properties.load(is);
                    for (Object key : properties.keySet()) {
                        String keyName = key.toString();
                        String clsName = properties.getProperty(keyName);
                        loader.typeMap.put(keyName, clsName);
                        Supplier<T> baseSupplier = () -> creator.apply(clsName);

                        if (memoize) {
                            com.google.common.base.Supplier<T> gsupplier = Suppliers.memoize(baseSupplier::get);
                            Supplier<T> jsupplier = gsupplier::get;

                            loader.suppliers.put(keyName, jsupplier);
                        } else {
                            loader.suppliers.put(keyName, baseSupplier);
                        }
                    }
                    loader.suppliers.putAll(registeSuppliers);
                } catch (IOException e) {
                    throw new IllegalArgumentException(e);
                }
            }
            return loader;
        }
    }

    public static <T> Builder<T> find(Class<T> t) {
        return new Builder<T>(t);
    }
}
