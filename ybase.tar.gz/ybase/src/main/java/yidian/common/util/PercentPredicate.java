package yidian.common.util;

import com.google.common.base.Predicate;

import javax.annotation.Nullable;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by sunshangchun on 16/4/29.
 * 按照比例通过过滤
 */
public class PercentPredicate<T> implements Predicate<T> {
    private final double samplePercentage;
    private final Random random = new Random();
    private AtomicLong totalCount = new AtomicLong(0);
    private AtomicLong passedCount = new AtomicLong(0);

    public PercentPredicate(double percent) {
        this.samplePercentage = percent;
    }

    public long getTotalCount() {
        return totalCount.get();
    }

    public long getPassedCount() {
        return passedCount.get();
    }

    @Override
    public boolean apply(@Nullable T t) {
        totalCount.incrementAndGet();
        double d = random.nextDouble();

        if (d < samplePercentage) {
            passedCount.incrementAndGet();
            return true;
        } else {
            return false;
        }
    }
}
