
package yidian.common.util;

/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Utility class that handles byte arrays, conversions to/from other types,
 * comparisons, hash code generation, manufacturing keys for HashMaps or
 * HashSets, and can be used as key in maps or trees.
 */
public class Bytes {
    //HConstants.UTF8_ENCODING should be updated if this changed
    /**
     * When we encode strings, we always specify UTF8 encoding
     */
    private static final String UTF8_ENCODING = "UTF-8";

    //HConstants.EMPTY_BYTE_ARRAY should be updated if this changed
    private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];

    /**
     * Size of boolean in bytes
     */
    public static final int SIZEOF_BOOLEAN = Byte.SIZE / Byte.SIZE;

    /**
     * Size of byte in bytes
     */
    public static final int SIZEOF_BYTE = SIZEOF_BOOLEAN;

    /**
     * Size of char in bytes
     */
    public static final int SIZEOF_CHAR = Character.SIZE / Byte.SIZE;

    /**
     * Size of double in bytes
     */
    public static final int SIZEOF_DOUBLE = Double.SIZE / Byte.SIZE;

    /**
     * Size of float in bytes
     */
    public static final int SIZEOF_FLOAT = Float.SIZE / Byte.SIZE;

    /**
     * Size of int in bytes
     */
    public static final int SIZEOF_INT = Integer.SIZE / Byte.SIZE;

    /**
     * Size of long in bytes
     */
    public static final int SIZEOF_LONG = Long.SIZE / Byte.SIZE;

    /**
     * Size of short in bytes
     */
    public static final int SIZEOF_SHORT = Short.SIZE / Byte.SIZE;

    /**
     * Mask to apply to a long to reveal the lower int only. Use like this:
     * int i = (int)(0xFFFFFFFF00000000L ^ some_long_value);
     */
    public static final long MASK_FOR_LOWER_INT_IN_LONG = 0xFFFFFFFF00000000L;

    // ------------------------------ //
    // Byte array conversion utilies. //
    // ------------------------------ //

    /**
     * Reads a big-endian 2-byte short from the begining of the given array.
     *
     * @param b The array to read from.
     * @return A short integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static short toShort(final byte[] b) {
        return toShort(b, 0);
    }

    /**
     * Reads a big-endian 2-byte short from an offset in the given array.
     *
     * @param b      The array to read from.
     * @param offset The offset in the array to start reading from.
     * @return A short integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static short toShort(final byte[] b, final int offset) {
        return (short) (b[offset] << 8 | b[offset + 1] & 0xFF);
    }

    /**
     * Reads a big-endian 2-byte unsigned short from the begining of the
     * given array.
     *
     * @param b The array to read from.
     * @return A positive short integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static int toUnsignedShort(final byte[] b) {
        return toUnsignedShort(b, 0);
    }

    /**
     * Reads a big-endian 2-byte unsigned short from an offset in the
     * given array.
     *
     * @param b      The array to read from.
     * @param offset The offset in the array to start reading from.
     * @return A positive short integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static int toUnsignedShort(final byte[] b, final int offset) {
        return toShort(b, offset) & 0x0000FFFF;
    }

    /**
     * Writes a big-endian 2-byte short at the begining of the given array.
     *
     * @param b The array to write to.
     * @param n A short integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static void setShort(final byte[] b, final short n) {
        setShort(b, n, 0);
    }

    /**
     * Writes a big-endian 2-byte short at an offset in the given array.
     *
     * @param b      The array to write to.
     * @param offset The offset in the array to start writing at.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static void setShort(final byte[] b, final short n,
                                final int offset) {
        b[offset + 0] = (byte) (n >>> 8);
        b[offset + 1] = (byte) (n >>> 0);
    }

    /**
     * Creates a new byte array containing a big-endian 2-byte short integer.
     *
     * @param n A short integer.
     * @return A new byte array containing the given value.
     */
    public static byte[] toBytes(final short n) {
        final byte[] b = new byte[2];
        setShort(b, n);
        return b;
    }

    /**
     * Reads a big-endian 4-byte integer from the begining of the given array.
     *
     * @param b The array to read from.
     * @return An integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static int toInt(final byte[] b) {
        return toInt(b, 0);
    }

    /**
     * Reads a big-endian 4-byte integer from an offset in the given array.
     *
     * @param b      The array to read from.
     * @param offset The offset in the array to start reading from.
     * @return An integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static int toInt(final byte[] b, final int offset) {
        return (b[offset + 0] & 0xFF) << 24
                | (b[offset + 1] & 0xFF) << 16
                | (b[offset + 2] & 0xFF) << 8
                | (b[offset + 3] & 0xFF) << 0;
    }

    /**
     * Reads a big-endian 4-byte unsigned integer from the begining of the
     * given array.
     *
     * @param b The array to read from.
     * @return A positive integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static long toUnsignedInt(final byte[] b) {
        return toUnsignedInt(b, 0);
    }

    /**
     * Reads a big-endian 4-byte unsigned integer from an offset in the
     * given array.
     *
     * @param b      The array to read from.
     * @param offset The offset in the array to start reading from.
     * @return A positive integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static long toUnsignedInt(final byte[] b, final int offset) {
        return toInt(b, offset) & 0x00000000FFFFFFFFL;
    }

    /**
     * Writes a big-endian 4-byte int at the begining of the given array.
     *
     * @param b The array to write to.
     * @param n An integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static void setInt(final byte[] b, final int n) {
        setInt(b, n, 0);
    }

    /**
     * Writes a big-endian 4-byte int at an offset in the given array.
     *
     * @param b      The array to write to.
     * @param offset The offset in the array to start writing at.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static void setInt(final byte[] b, final int n, final int offset) {
        b[offset + 0] = (byte) (n >>> 24);
        b[offset + 1] = (byte) (n >>> 16);
        b[offset + 2] = (byte) (n >>> 8);
        b[offset + 3] = (byte) (n >>> 0);
    }

    /**
     * Creates a new byte array containing a big-endian 4-byte integer.
     *
     * @param n An integer.
     * @return A new byte array containing the given value.
     */
    public static byte[] toBytes(final int n) {
        final byte[] b = new byte[4];
        setInt(b, n);
        return b;
    }

    /**
     * Reads a big-endian 8-byte long from the begining of the given array.
     *
     * @param b The array to read from.
     * @return A long integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static long toLong(final byte[] b) {
        return toLong(b, 0);
    }

    /**
     * Reads a big-endian 8-byte long from an offset in the given array.
     *
     * @param b      The array to read from.
     * @param offset The offset in the array to start reading from.
     * @return A long integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static long toLong(final byte[] b, final int offset) {
        return (b[offset + 0] & 0xFFL) << 56
                | (b[offset + 1] & 0xFFL) << 48
                | (b[offset + 2] & 0xFFL) << 40
                | (b[offset + 3] & 0xFFL) << 32
                | (b[offset + 4] & 0xFFL) << 24
                | (b[offset + 5] & 0xFFL) << 16
                | (b[offset + 6] & 0xFFL) << 8
                | (b[offset + 7] & 0xFFL) << 0;
    }

    /**
     * Writes a big-endian 8-byte long at the begining of the given array.
     *
     * @param b The array to write to.
     * @param n A long integer.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static void setLong(final byte[] b, final long n) {
        setLong(b, n, 0);
    }

    /**
     * Writes a big-endian 8-byte long at an offset in the given array.
     *
     * @param b      The array to write to.
     * @param offset The offset in the array to start writing at.
     * @throws IndexOutOfBoundsException if the byte array is too small.
     */
    public static void setLong(final byte[] b, final long n, final int offset) {
        b[offset + 0] = (byte) (n >>> 56);
        b[offset + 1] = (byte) (n >>> 48);
        b[offset + 2] = (byte) (n >>> 40);
        b[offset + 3] = (byte) (n >>> 32);
        b[offset + 4] = (byte) (n >>> 24);
        b[offset + 5] = (byte) (n >>> 16);
        b[offset + 6] = (byte) (n >>> 8);
        b[offset + 7] = (byte) (n >>> 0);
    }

    /**
     * Creates a new byte array containing a big-endian 8-byte long integer.
     *
     * @param n A long integer.
     * @return A new byte array containing the given value.
     */
    public static byte[] toBytes(final long n) {
        final byte[] b = new byte[8];
        setLong(b, n);
        return b;
    }
}

