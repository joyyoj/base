package yidian.common.util;

import java.util.AbstractMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by sunshangchun on 16/11/3.
 */ // maintain two state, always one in active state at the same time
public class ABStateObject<T> {
    private final AtomicBoolean aIsActive = new AtomicBoolean(true);
    private final T objectA;
    private final T objectB;

    public ABStateObject(T v0, T v1) {
        this.objectA = v0;
        this.objectB = v1;
        aIsActive.set(true);
    }

    public T getUnActiveObject() {
        if (aIsActive.get()) {
            return objectB;
        }
        return objectA;
    }

    public T getActiveObject() {
        if (aIsActive.get()) {
            return objectA;
        }
        return objectB;
    }

    // switch state and return the active object before switch
    public synchronized T switchState() {
        while (true) {
            boolean current = aIsActive.get();
            if (aIsActive.compareAndSet(current, !current)) {
                if (current) {
                    return objectA;
                }
                return objectB;
            }
        }
    }

    public Map.Entry<T, T> getAll() {
       return new AbstractMap.SimpleImmutableEntry<>(objectA, objectB);
    }
}
