package yidian.common.io;

import com.google.common.io.Files;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class FileUtils {
    // If targetLocation does not exist, it will be created.
    public static void copyDirectory(File sourceLocation, File targetLocation)
            throws IOException {
        if (sourceLocation.isDirectory()) {
            if (!targetLocation.exists()) {
                targetLocation.mkdir();
            }
            String[] children = sourceLocation.list();

            for (int i = 0; i < children.length; i++) {
                copyDirectory(new File(sourceLocation, children[i]),
                        new File(targetLocation, children[i]));
            }
        } else {
            Files.copy(sourceLocation, targetLocation);
        }
    }

    public static boolean mkDirRecursively(File file) {
        if (file.exists()) {
            return true;
        } else {
            if (mkDirRecursively(file.getParentFile())) {
                return file.mkdir();
            } else {
                return false;
            }
        }
    }

    public static void writeToFile(InputStream is, File out) throws Exception {
        FileOutputStream fos = new FileOutputStream(out);
        byte[] buffer = new byte[2048];
        int nBytes = 0;

        while ((nBytes = is.read(buffer)) > 0) {  // write contents of 'is' to 'fos'
            fos.write(buffer, 0, nBytes);
        }
        fos.close();
        is.close();
    }
}
