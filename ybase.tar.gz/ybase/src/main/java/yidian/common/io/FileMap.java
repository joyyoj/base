package yidian.common.io;

import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import lombok.Data;
import lombok.Setter;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import yidian.common.base.ByteArray;
import yidian.common.base.StorageUnit;

import java.io.*;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static yidian.common.io.FileMap.FileMeta.DEFAULT_PAGE_SIZE;
import static yidian.common.io.FileMap.FileMeta.VERSION_STAMP;

/**
 * Append only kv store, load index in memory. lost all data if crash.
 * TODO: save index to file for the recovery.
 * not thread-safely
 */
@Slf4j
public class FileMap<Key, Value> extends AbstractMap<Key, Value> {
    private static final int META_SIZE = 4096; // 4k for header
    private static final int MAX_FILE_SIZE = Integer.MAX_VALUE;
    private final AtomicInteger currentAllocatePageOffset = new AtomicInteger(META_SIZE);
    private final File dataFile;
    private final FileChannel fileChannel;
    private final Index<Key> index;
    private int fileSize; // todo file size, should be growth dynamic.
    private FileMeta<Key, Value> meta;
    private MappedByteBuffer mappedBuffer;
    private volatile boolean isCleanUp = false;

    @Accessors(chain = true)
    @Setter
    private boolean persist = false;

    @Accessors(chain = true)
    @Setter
    private boolean fixed = false; // for debug usage

    // open for read write
    protected FileMap(File file) throws IOException {
        this.dataFile = file;
        fileChannel = new RandomAccessFile(file, "rw").getChannel();
        File indexFile = new File(file.getParent(), file.getName() + ".idx");
        index = new Index<>(indexFile);
        Preconditions.checkArgument(file.length() <= Integer.MAX_VALUE, "large file not support");
        this.fileSize = (int) file.length();

        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                cleanUp();
            }
        });
    }

    public static <K, V> FileMap<K, V> create(File file, FileMeta<K, V> meta) throws IOException {
       return create(file, (int) StorageUnit.MB.toBytes(100), meta);
    }

    public static <K, V> FileMap<K, V> create(File file, int initSize, FileMeta<K, V> meta) throws IOException {
        val fileMap = new FileMap<K, V>(file);
        fileMap.create(initSize, meta);
        return fileMap;
    }

    public static <K, V> FileMap<K, V> open(File file) throws IOException {
        val fileMap = new FileMap<K, V>(file);
        fileMap.open();
        return fileMap;
    }

    public static <K, V> FileMeta<K, V> newMeta(SerDe<K> key, SerDe<V> value) {
        val meta = new FileMeta<K, V>(key, value);
        meta.setPageSize(value.getFixedSize() == 0 ? DEFAULT_PAGE_SIZE : value.getFixedSize());
        return meta;
    }

    private void create(int fileSize, FileMeta<Key, Value> meta) throws IOException {
        Preconditions.checkArgument(fileSize <= Integer.MAX_VALUE);
        mappedBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, fileSize);
        this.meta = meta;
        this.fileSize = fileSize;
    }

    private void open() throws IOException {
        mappedBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, fileSize);
        meta = loadMeta();
        checkMeta();
        index.load(this.meta.getKeySerDe());
    }

    private void checkMeta() {
        if (!meta.version.equals(VERSION_STAMP)) {
            throw new VersionMismatchException("current version " + meta.version
                    + " expected version " + VERSION_STAMP);
        }
    }

    public FileMap<Key, Value> deleteOnExit() {
        this.index.indexFile.deleteOnExit();
        this.dataFile.deleteOnExit();
        return this;
    }

    FileMeta<Key, Value> loadMeta() throws IOException {
        mappedBuffer.position(0);
        int metaSize = mappedBuffer.getInt();
        byte[] buf = readPage(PageOffset.of(4, metaSize));
        FileMeta<Key, Value> meta = FileMeta.parseFrom(CodedInputStream.newInstance(buf));

        return meta;
    }

    void saveMeta() throws IOException {
        byte[] bs = meta.toByteArray();

        Preconditions.checkState(bs.length < META_SIZE);
        mappedBuffer.position(0);
        mappedBuffer.putInt(bs.length);
        mappedBuffer.put(bs, 0, bs.length);
    }

    @Override
    public void clear() {
        this.currentAllocatePageOffset.set(0);
        this.index.clear();
    }

    public void cleanUp() {
        if (!isCleanUp && this.meta != null && this.mappedBuffer != null) {
            try {
                saveMeta();
                if (persist) {
                    index.save(this.meta.getKeySerDe());
                }
                mappedBuffer.force();
                mappedBuffer.clear();
                fileChannel.truncate(this.currentAllocatePageOffset.get());
                fileChannel.close();
            } catch (IOException ie) {
                log.error("failed to cleanUp", ie);
            } finally {
                isCleanUp = true;
            }
        }
    }

    private boolean grow(int capacity) {
        if (fixed) {  // disable
            return false;
        }
        if (capacity > MAX_FILE_SIZE) {
            return false;
        } else {
            try {
                mappedBuffer.force();
                mappedBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, capacity);
                this.fileSize = capacity;

                return true;
            } catch (IOException ie) {
                log.error("failed to trim to size " + capacity);
                return false;
            }
        }
    }

    private byte[] readPage(PageOffset pageOffset) {
        byte[] dst = new byte[pageOffset.getLength()];
        mappedBuffer.position((int) pageOffset.start);
        mappedBuffer.get(dst, 0, pageOffset.getLength());
        return dst;
    }

    private void append(Key key, Value tuple) {
        ByteArray bs = meta.valueSerDe.serialize(tuple);
        PageOffset pageOffset = allocatePage(bs.size());

        mappedBuffer.position((int) pageOffset.start);
        mappedBuffer.put(bs.array(), bs.offset(), bs.size());
        index.map.put(key, pageOffset);
    }

    private PageOffset allocatePage(int allocateSize) throws DiskOverflowException {
        int pageCount = (allocateSize + meta.pageSize - 1) / meta.pageSize;
        int len = pageCount * meta.pageSize;
        int start;

        do {
            start = currentAllocatePageOffset.get();

            if (start + allocateSize >= fileSize) {
                if (!grow(MAX_FILE_SIZE)) {  // grow to max file size.
                    String errorMsg = "failed to allocate new page " + allocateSize + " , current size:" +
                            start + " fileSize:" + fileSize + " pageCount:" + pageCount + " len:" + len;
                    log.error(errorMsg);
                    throw new DiskOverflowException(new Exception(errorMsg));
                }
            }
        } while (!currentAllocatePageOffset.compareAndSet(start, Math.min(start + len, fileSize)));

        return PageOffset.of(start, allocateSize);
    }

    @Override
    public boolean containsKey(Object key) {
        return index.map.containsKey(key);
    }

    @Override
    public Value remove(Object key) {
        Value value = get(key);

        if (value != null) {
            index.map.remove(key);
        }
        return value;
    }

    @Override
    public Value get(Object key) {
        PageOffset pageOffset = index.map.get(key);

        if (pageOffset == null) {
            return null;
        } else {
            byte[] values = readPage(pageOffset);

            return meta.valueSerDe.deserialize(ByteArray.ref(values));
        }
    }

    // always append, and update index
    @Override
    public Value put(Key key, Value value) {
        append(key, value);
        return value;
    }

    public long getAllocatedBytes() {
        return currentAllocatePageOffset.get();
    }

    public long getTotalBytes() {
        return fileSize;
    }

    @Override
    public int size() {
        return index.map.size();
    }

    @Override
    public Set<Key> keySet() {
        return index.map.keySet();
    }

    @Override
    public Set<Entry<Key, Value>> entrySet() {
        return new EntrySet();
    }

    @Data(staticConstructor = "of")
    static class PageOffset implements Serializable {
        final int start;
        final int length;
    }

    /**
     * DiskOverflow Exception.
     */
    public static class DiskOverflowException extends RuntimeException {
        public DiskOverflowException(Throwable e) {
            super(e);
        }
    }

    public static class VersionMismatchException extends RuntimeException {
        public VersionMismatchException(String error) {
            super(error);
        }
    }

    @Accessors(chain = true)
    @Data
    public static class FileMeta<K, V> {
        public static final String VERSION_STAMP = "yidian.data.filemap-1.0";
        public static final int DEFAULT_PAGE_SIZE = 4096; // 4k

        private final SerDe<K> keySerDe;

        private final SerDe<V> valueSerDe;

        private String version = VERSION_STAMP;

        private int pageSize;

        public static <K, V> FileMeta<K, V> parseFrom(CodedInputStream cis) throws IOException {
            String version = cis.readString();
            String keySerDeCls = cis.readString();
            String valueSerDeCls = cis.readString();

            try {
                val keyCls = (Class<? extends SerDe<K>>) Class.forName(keySerDeCls);
                val keySerDe = keyCls.newInstance();

                val valCls = (Class<? extends SerDe<V>>) Class.forName(valueSerDeCls);
                val valueSerDe = valCls.newInstance();

                int pageSize = cis.readInt32();
                return newMeta(keySerDe, valueSerDe).setVersion(version).setPageSize(pageSize);
            } catch (Exception e) {
               log.error("failed to load meta ", e);
            }
            return null;
        }

        public void serialize(CodedOutputStream cos) throws IOException {
            cos.writeStringNoTag(version);
            cos.writeStringNoTag(keySerDe.getClass().getName());
            cos.writeStringNoTag(valueSerDe.getClass().getName());
            cos.writeInt32NoTag(pageSize);
        }

        public byte[] toByteArray() throws IOException {
            val bos = new ByteArrayOutputStream(150);
            CodedOutputStream cos = CodedOutputStream.newInstance(bos);

            serialize(cos);
            cos.flush();
            return bos.toByteArray();
        }
    }

    @Data
    public static class Index<K> {
        final File indexFile;
        Map<K, PageOffset> map = new HashMap<>(512);

        public void load(SerDe<K> keySerDe) throws IOException {
            if (!indexFile.exists()) {
                return;
            }
            try (val is = new BufferedInputStream(new FileInputStream(indexFile))) {
                val cis = CodedInputStream.newInstance(is);
                cis.setSizeLimit(Integer.MAX_VALUE);
                val size = cis.readInt32();

                Preconditions.checkState(size >= 0 && size < Integer.MAX_VALUE);
                map = Maps.newHashMapWithExpectedSize(size);
                int keyLen = keySerDe.getFixedSize();

                if (keyLen == 0) {
                    for (int i = 0; i < size; ++i) {
                        val bytes = cis.readBytes();
                        K key = keySerDe.deserialize(ByteArray.ref(bytes.toByteArray()));
                        int start = cis.readInt32();
                        int length = cis.readInt32();

                        if (key != null) {
                            map.put(key, PageOffset.of(start, length));
                        }
                    }
                } else { // key len is fixed.
                    for (int i = 0; i < size; ++i) {
                        try {
                            val bytes = cis.readRawBytes(keyLen);
                            K key = keySerDe.deserialize(ByteArray.ref(bytes));
                            int start = cis.readInt32();
                            int length = cis.readInt32();

                            if (key != null) {
                                map.put(key, PageOffset.of(start, length));
                            }
                        } catch (IOException e) {
                            log.error("failed to read " + size, e);
                            throw e;
                        }
                    }
                }
            }
        }

        public void clear() {
            map.clear();
        }

        public void save(SerDe<K> keySerDe) throws IOException {
            if (indexFile.exists()) {
                indexFile.delete();
            }
            try (val os = new BufferedOutputStream(new FileOutputStream(indexFile))) {
                CodedOutputStream cos = CodedOutputStream.newInstance(os);
                cos.writeInt32NoTag(map.size());  // length

                if (keySerDe.getFixedSize() == 0) {
                    for (val entry : map.entrySet()) {
                        val ba = keySerDe.serialize(entry.getKey());

                        cos.writeByteArrayNoTag(ba.getOrCopyBytes());
                        cos.writeInt64NoTag(entry.getValue().start);
                        cos.writeInt32NoTag(entry.getValue().getLength());
                    }
                } else {  // key len is fixed
                    for (val entry : map.entrySet()) {
                        val ba = keySerDe.serialize(entry.getKey());

                        cos.writeRawBytes(ba.array(), ba.offset(), ba.size());
                        cos.writeInt64NoTag(entry.getValue().start);
                        cos.writeInt32NoTag(entry.getValue().getLength());
                    }
                }
                cos.flush();
            }
        }
    }

    public static class ObjectIterator<K, V> implements Iterator<Map.Entry<K, V>> {
        final Iterator<K> keyIterator;
        final Function<K, V> getter;

        public ObjectIterator(Iterator<K> keyIter, Function<K, V> getter) {
            this.keyIterator = keyIter;
            this.getter = getter;
        }

        @Override
        public boolean hasNext() {
            return keyIterator.hasNext();
        }

        @Override
        public Map.Entry<K, V> next() {
            K key = keyIterator.next();
            V tuple = getter.apply(key);
            return new AbstractMap.SimpleEntry<>(key, tuple);
        }

        @Override
        public void remove() {
            keyIterator.remove();
        }
    }

    public class EntrySet extends AbstractSet<Entry<Key, Value>> {

        @Override
        public Iterator<Entry<Key, Value>> iterator() {
            return new ObjectIterator<>(index.map.keySet().iterator(), (k) -> get(k));
        }

        @Override
        public int size() {
            return FileMap.this.size();
        }

        @Override
        public boolean remove(Object o) {
            Value v = FileMap.this.remove(o);
            return v != null;
        }
    }
}

