package yidian.common.io;

import yidian.common.base.ByteArray;

/**
 * Created by sunshangchun on 16/3/23.
 */
public interface Deserializer<Value> {
    Value deserialize(ByteArray byteArray);
}
