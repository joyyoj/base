package yidian.common.io;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import lombok.val;
import yidian.common.base.ByteArray;
import yidian.common.util.Bytes;

import java.io.ByteArrayOutputStream;

/**
 * Created by sunshangchun on 16/11/8.
 */
public class SerDes {
    public static SerDe<Integer> fixedInt32SerDe = new SerDe<Integer>() {
        @Override
        public Integer deserialize(ByteArray byteArray) {
            return Bytes.toInt(byteArray.array(), byteArray.offset());
        }

        @Override
        public ByteArray serialize(Integer integer) {
            return ByteArray.ref(Bytes.toBytes(integer));
        }

        @Override
        public int getFixedSize() {
            return Bytes.SIZEOF_INT;
        }
    };

    public static SerDe<Long> fixedInt64SerDe = new SerDe<Long>() {
        @Override
        public Long deserialize(ByteArray byteArray) {
            return Bytes.toLong(byteArray.array(), byteArray.offset());
        }

        @Override
        public ByteArray serialize(Long aLong) {
            return ByteArray.ref(Bytes.toBytes(aLong));
        }

        @Override
        public int getFixedSize() {
            return Bytes.SIZEOF_LONG;
        }
    };

    public static SerDe<Double> fixedDoubleSerDe = new SerDe<Double>() {
        @Override
        public Double deserialize(ByteArray byteArray) {
            long lv = Bytes.toLong(byteArray.array(), byteArray.offset());
            return Double.longBitsToDouble(lv);
        }

        @Override
        public ByteArray serialize(Double aDouble) {
            long lv = Double.doubleToLongBits(aDouble);
            return ByteArray.ref(Bytes.toBytes(lv));
        }

        @Override
        public int getFixedSize() {
            return Bytes.SIZEOF_LONG;
        }
    };

    public static SerDe<String> stringSerDe = new SerDe<String>() {
        @Override
        public String deserialize(ByteArray byteArray) {
            try {
                CodedInputStream cis = CodedInputStream.newInstance(byteArray.array(),
                        byteArray.offset(), byteArray.size());

                return cis.readString();
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        public ByteArray serialize(String s) {
            try {
                val bos = new ByteArrayOutputStream(s.length() * 3);
                CodedOutputStream cos = CodedOutputStream.newInstance(bos);

                cos.writeStringNoTag(s);
                cos.flush();
                return ByteArray.ref(bos.toByteArray());
            } catch (Exception e) {
                return null;
            }
        }
    };
}
