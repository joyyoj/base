package yidian.common.io;

/**
 * response for serialize/deserialize value
 */
public interface SerDe<Value> extends Serializer<Value> , Deserializer<Value> {
    /**
     * if the byte array's size for type Value. 0 if size is not determinate.
     * eg. integer type, 4 bytes, for long type, 8 bytes. for string type, 0.
     * @return 0 if vary, otherwise return the fixed size
     */
    default int getFixedSize() {
        return 0;
    }
}
