package yidian.common.io;

import com.google.common.io.ByteStreams;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class ZipUtils {
    private static final int BUFFER_SIZE = 8192;

    /**
     * pack folder into zip file.
     */
    public static void zipFolder(final File folder, final File zipFile) throws IOException {
        if (zipFile.getParentFile() != null && !zipFile.getParentFile().exists()) {
            zipFile.getParentFile().mkdirs();
        }
        zipFolder(folder, new FileOutputStream(zipFile));
    }

    /**
     * pack folder into zipoutputstream.
     */
    public static void zipFolder(final File folder, final OutputStream outputStream)
            throws IOException {
        try (ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream)) {
            processFolder(folder, zipOutputStream, folder.getPath().length() + 1);
        }
    }

    /***
     * Extract zipFile to outDir with complete directory structure
     *
     * @param zipFile Input .zip file
     * @param outDir  Output directory
     */
    public static void unzipFile(File zipFile, File outDir) throws IOException {
        if (!outDir.exists()) {
           outDir.mkdirs();
        }
        try (ZipInputStream zin = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            String name, dir;

            while ((entry = zin.getNextEntry()) != null) {
                name = entry.getName();
                if (entry.isDirectory()) {
                    mkdirs(outDir, name);
                } else {
                    // file entry can come before directory entry where is file located,
                    // ie: /foo/foo.txt, /foo
                    dir = getDirPart(name);
                    if (dir != null) {
                        mkdirs(outDir, dir);
                    }
                    extraceFile(zin, outDir, name);
                }
            }
        }
    }

    private static void extraceFile(ZipInputStream in, File outDir, String name) throws IOException {
        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(
                new File(outDir, name)))) {
            int count = -1;
            byte[] buffer = new byte[BUFFER_SIZE];

            while ((count = in.read(buffer)) != -1) {
                out.write(buffer, 0, count);
            }
        }
    }

    private static void mkdirs(File outDir, String path) {
        File d = new File(outDir, path);

        if (!d.exists()) {
            d.mkdirs();
        }
    }

    private static String getDirPart(String name) {
        int s = name.lastIndexOf(File.separatorChar);
        return s == -1 ? null : name.substring(0, s);
    }


    private static void processFolder(final File folder, final ZipOutputStream zipOutputStream,
                                      final int prefixLength) throws IOException {
        for (final File file : folder.listFiles()) {
            if (file.isFile()) {
                final ZipEntry zipEntry = new ZipEntry(file.getPath().substring(prefixLength));

                zipOutputStream.putNextEntry(zipEntry);
                try (FileInputStream inputStream = new FileInputStream(file)) {
                    ByteStreams.copy(inputStream, zipOutputStream);
                }
                zipOutputStream.closeEntry();
            } else if (file.isDirectory()) {
                processFolder(file, zipOutputStream, prefixLength);
            }
        }
    }
}
