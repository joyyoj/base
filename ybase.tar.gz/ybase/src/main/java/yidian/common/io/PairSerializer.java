package yidian.common.io;

import org.apache.commons.lang3.tuple.Pair;


public interface PairSerializer<K, V> extends SerDe<Pair<K, V>> {

}
