package yidian.common.io;


import com.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 简单的基于文件的KeyValue存储类. 非线程安全
 *
 * 为了避免频繁的读写hbase,先把数据buffer住一段时间,然后写入一批keyvalue到hbase中.
 * 在数据量很大的情况下,kv全部放到 Map 中会导致 OutOfMemory. 而使用现成的单机keyvalue系统有一些问题.
 * 如 mapdb性能奇慢,而java版的leveldb似乎有内存泄露,占用内存很大. 因此自己实现了一个简单的keyvalue存储类.
 * 具体做法就是: 在内存开辟一段空间,kv先写入到Map,溢出后使用LRU替换记录写入到文件中.
 * 出于性能考虑,文件只是追加. 文件的 meta 信息全部存放在内存中.
 * 实现简单高效,但存在几个问题:
 * 1. 因为文件使用mmap方式,而java mmap限制最大2g,因此文件写满2g后,将导致无法继续写入;记录丢失;
 * 2. 记录写入没有日志,因此一旦crash后,数据丢失.
 * 目前丢失一点数据不太影响,而在正常情况下,不会写满,进程也不会crash,因此现在直接使用.
 */
public class CacheBasedMap<K, V>  extends AbstractMap<K, V> {
    private static final Logger logger = LoggerFactory.getLogger(CacheBasedMap.class);
    private final FileMap<K, V> fileCache;
    private final LruCache<K, V> lruCache;
    private final Set<K> keySet = new HashSet<>();

    public CacheBasedMap(FileMap<K, V> fileMap, int cacheSize) {
        Preconditions.checkArgument(cacheSize > 0);
        this.fileCache = fileMap;
        this.lruCache = new LruCache<>(cacheSize);

        LruCache.RemovalListener<K, V> removalListener = (key, value) -> {
            try {
                fileCache.put(key, value);
            } catch (FileMap.DiskOverflowException ef) {
                throw ef;
            } catch (Exception e) {
                keySet.remove(key);
                logger.error(String.format("Could not persist key-value: %s, %s", key, value), e);
            }
        };
        lruCache.setRemovalListener(removalListener);
    }

    public V put(K key, V value) {
        keySet.add(key);
        lruCache.put(key, value);
        return value;
    }

    @Override
    public boolean containsKey(Object key) {
        return keySet.contains(key);
    }

    @Override
    public V remove(Object key) {
        throw new UnsupportedOperationException("remove not supported");
    }

    public V get(Object key) {
        V tuple = lruCache.get(key);
        if (tuple == null) {
            return fileCache.get(key);
        }
        return tuple;
    }

    @Override
    public void clear() {
        this.keySet.clear();
        this.lruCache.clear();
        this.fileCache.clear();
    }

    @Override
    public int size() {
        return keySet.size();
    }

    @Override
    public Set<Entry<K, V>> entrySet() { // todo not
        return new EntrySet();
    }


    // shut down, clear all and close file
    public void shutDown() {
        this.keySet.clear();
        this.lruCache.clear();
        this.fileCache.cleanUp();
    }

    @Override
    public Set<K> keySet() {
        return keySet;
    }

    public class EntrySet extends AbstractSet<Entry<K, V>> {
        @Override
        public Iterator<Entry<K, V>> iterator() {
            return CacheBasedMap.this.iterator();
        }

        @Override
        public int size() {
            return CacheBasedMap.this.size();
        }

        @Override
        public boolean remove(Object o) {
            V v = CacheBasedMap.this.remove(o);
            return v != null;
        }
    }

    public Iterator<Map.Entry<K, V>> iterator() {
        return new FileMap.ObjectIterator<>(keySet.iterator(), (k) -> get(k));
    }
}
