package yidian.common.io;

import yidian.common.base.ByteArray;

/**
 * Created by sunshangchun on 16/3/23.
 */
public interface Serializer<Value> {
    ByteArray serialize(Value value);
}
