package yidian.common.io;

import com.google.common.base.Charsets;
import com.google.common.io.Files;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class IOUtils {
    public static List<String> readLines(String resourceName) throws IOException {
        File dict = new File(resourceName);

        if (dict.exists() && dict.isFile()) {
            return Files.readLines(dict, Charsets.UTF_8);
        }

        // read from jar
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourceName);

        if (is != null) {
            List<String> sb = new ArrayList<>();

            try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                String line;

                while ((line = br.readLine()) != null) {
                    sb.add(line);
                }
                return sb;
            } finally {
                is.close();
            }
        } else {
            throw new IOException("file " + resourceName + " not found");
        }
    }
}
