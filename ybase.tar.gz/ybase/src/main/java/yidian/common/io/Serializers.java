package yidian.common.io;

import com.google.common.base.Charsets;
import org.apache.commons.lang3.tuple.Pair;
import yidian.common.base.ByteArray;

/**
 * Created by sunshangchun on 15/12/18.
 */
public class Serializers {
    public static class StrSerializer implements SerDe<String> {
        @Override
        public ByteArray serialize(String s) {
            return ByteArray.ref(s.getBytes());
        }

        @Override
        public String deserialize(ByteArray byteArray) {
            return new String(byteArray.array(), byteArray.offset(), byteArray.size());
        }
    }

    public static class StringSerializer implements PairSerializer<String, String> {
        @Override
        public ByteArray serialize(Pair<String, String> entry) {
            StringBuilder sb = new StringBuilder();
            sb.append(entry.getKey());
            sb.append(",");
            sb.append(entry.getValue());
            return ByteArray.copyFrom(sb.toString(), Charsets.UTF_8);
        }

        @Override
        public Pair<String, String> deserialize(ByteArray bs) {
            String[] out = new String(bs.array(), bs.offset(), bs.size()).split(",");
            return Pair.of(out[0], out[1]);
        }
    }

//    public static <K, V> PairSerializer<K, V> createPair(SerDe<K> keySerDe, SerDe<V> valueSerDe) {
//    }
//
//    private static class DefaultPairSerializer<K, V> implements PairSerializer<K, V> {
//        SerDe<K> keySerDe;
//        SerDe<V> valueSerDe;
//
//        @Override
//        public Pair<K, V> deserialize(ByteArray byteArray) {
//            keySerDe.serialize();
//            return null;
//        }
//
//        @Override
//        public ByteArray serialize(Pair<K, V> kvPair) {
//            return null;
//        }
//    }
}
