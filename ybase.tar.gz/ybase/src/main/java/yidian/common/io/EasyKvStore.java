package yidian.common.io;

import com.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import yidian.common.base.ByteArray;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * [len:keyLen:key;value] (pageSize)
 */
public class EasyKvStore<T> {
    private EasyFile easyFile;
    private SerDe<T> serDe;

    public void put(ByteArray key, T value) {
        serDe.serialize(value);
    }

    public T get(ByteArray key) {
        ByteArray value = null;
        return serDe.deserialize(value);
    }

    private static class PageOffset {
        long start;
        long end;

        public int length() {
            return (int)(end - start);
        }
    }

    /**
     * DiskOverflow Exception.
     */
    public static class DiskOverflowException extends RuntimeException {
        public DiskOverflowException(Throwable e) {
            super(e);
        }
    }

//    public static class Builder<Key, Value> {
//        PairSerializer<Key, Value> serializer;
//        File file;
//        long fileSize;
//
//        public Builder setSerializer(PairSerializer<Key, Value> serializer) {
//            this.serializer = serializer;
//            return this;
//        }
//
//        public Builder setFile(File file) {
//            this.file = file;
//            return this;
//        }
//
//        public Builder setFileSize(long fileSize) {
//            this.fileSize = fileSize;
//            return this;
//        }
//
//        public Key, Value> build() throws IOException {
//            fileMap = new >(file, fileSize);
//            fileMap.serializer = serializer;
//            return fileMap;
//        }
//    }

    public static class Block implements Closeable {
        private static final Logger logger = LoggerFactory.getLogger(Block.class);
        private static final int DEFAULT_PAGE_SIZE = 4096; // 4k
        public final int pageSize;
        private final long fileSize;
        private final MappedByteBuffer mappedBuffer;
        private final FileChannel fileChannel;
        private long currentAllocatePageOffset = 0;
        private boolean isClosed = false;

        protected Block(File file, long fileSize, int pageSize) throws IOException {
            Preconditions.checkArgument(fileSize <= Integer.MAX_VALUE);
            this.pageSize = pageSize;
            this.fileSize = fileSize;
            fileChannel = new RandomAccessFile(file, "rw").getChannel();
            mappedBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, fileSize);
            Runtime.getRuntime().addShutdownHook(new Thread() {
                public void run() {
                    close();
                }
            });
        }

        public void clear() {
            this.currentAllocatePageOffset = 0;
        }

        @Override
        public void close() {
            if (!isClosed) {
                try {
                    mappedBuffer.force();
                    mappedBuffer.clear();
                    fileChannel.close();
                } catch (IOException ie) {
                    logger.error("failed to cleanUp", ie);
                } finally {
                    isClosed = true;
                }
            }
        }

        public byte[] readPage(PageOffset pageOffset) {
            byte[] dst = new byte[pageOffset.length()];
            mappedBuffer.position((int) pageOffset.start);
            mappedBuffer.get(dst, 0, pageOffset.length());
            return dst;
        }

        public PageOffset append(ByteArray bs) {
            PageOffset pageOffset = allocatePage(bs.size());

            mappedBuffer.position((int) pageOffset.start);
            mappedBuffer.put(bs.array(), 0, bs.size());
            return pageOffset;
        }

        private PageOffset allocatePage(int allocateSize) throws DiskOverflowException {
            int pageCount = (allocateSize + pageSize - 1) / pageSize;
            int len = pageCount * pageSize;
            PageOffset pageOffset = new PageOffset();

            pageOffset.start = currentAllocatePageOffset;
            pageOffset.end = pageOffset.start +  allocateSize;
            currentAllocatePageOffset += len;

            if (pageOffset.end >= fileSize) { // TODO map to a larger file
                String errorMsg = "failed to allocate new page, current size:" +
                        pageOffset.end + " fileSize:" + fileSize;

                logger.error(errorMsg);
                throw new DiskOverflowException(new Exception(errorMsg));
            }
            return pageOffset;
        }

        public long size() {
            return currentAllocatePageOffset;
        }

        public long capacity() {
            return fileSize;
        }
    }

    private static class FileHeader {
        int headerSize;
        int pageSize;
    }

    private static class EasyFile {
//        FileMeta fileMeta;
        private Map<ByteArray, PageOffset> indexes;
        Map<Integer, Block> blockList = new LinkedHashMap<>();
//        private List<>

        PageOffset get(ByteArray key) {
            PageOffset pageOffset = indexes.get(key);

            return pageOffset;
        }

//        Page readPage(int chunkId, int pageId) {
//            return null;
//        }

        void allocatePage() {
        }
    }
}
