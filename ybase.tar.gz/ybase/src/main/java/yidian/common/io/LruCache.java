package yidian.common.io;

import java.util.*;

/**
 * simple LruCache implementation, listenable (setRemovalListener)
 * Not thread safely, you should use guava cache instead.
 */
public class LruCache<A, B> extends LinkedHashMap<A, B> {
    private final int maxEntries;
    private RemovalListener<A, B> listener;
    private CacheLoader<A, B> cacheLoader;

    public LruCache(final int maxEntries) {
        super(maxEntries + 1, 1.0f, true);
        this.maxEntries = maxEntries;
    }

    public LruCache setRemovalListener(RemovalListener<A, B> listener) {
        this.listener = listener;
        return this;
    }

    @Override
    protected boolean removeEldestEntry(final Map.Entry<A, B> eldest) {
        if (super.size() > maxEntries) { // overflow
            if (listener != null) {
                listener.removeEldestEntry(eldest.getKey(), eldest.getValue());
            }
            return true;
        } else {
            return false;
        }
    }

    @Override
    public B get(Object key) {
        B b = super.get(key);

        if (b == null && cacheLoader != null) {
            b = cacheLoader.load((A) key);
            if (b != null) {
                put((A) key, b);
            }
        }
        return b;
    }

    public Map<A, B> getAll(List<A> keys) {
        Map<A, B> output = new HashMap<>();
        boolean hasLoader = (cacheLoader != null);
        List<A> missed = new ArrayList<>();

        for (A key : keys) {
            B v = super.get(key);

            if (v != null) {
                output.put(key, v);
            } else if (hasLoader) {
                missed.add(key);
            }
        }
        if (hasLoader) {
            Map<A, B> loadMap = cacheLoader.loadAll(missed);

            for (Map.Entry<A, B> entry : loadMap.entrySet()) {
                put(entry.getKey(), entry.getValue());
            }
            output.putAll(loadMap);
        }
        return output;
    }

    public B getIfPresent(A key) {
       return super.get(key);
    }

    public LruCache setCacheLoader(CacheLoader<A, B> cacheLoader) {
        this.cacheLoader = cacheLoader;

        return this;
    }

    public interface RemovalListener<A, B> {
        void removeEldestEntry(A key, B value);
    }

    public interface CacheLoader<K, V> {
        V load(K k);

        Map<K, V> loadAll(List<K> k);
    }
}
